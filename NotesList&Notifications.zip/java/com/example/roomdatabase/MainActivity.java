package com.example.roomdatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.roomdatabase.database.RoomDB;
import com.example.roomdatabase.database.MainData;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // initialize Variables
    EditText editText;
    RecyclerView recyclerView;
    Button btAdd, btReset;



    List<MainData> dataList = new ArrayList<>();
    LinearLayoutManager linearLayoutManager;
    RoomDB database;


    MainAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assign Variables
        editText = findViewById(R.id.edit_text);
        btAdd = findViewById(R.id.bt_add);
        btReset = findViewById(R.id.bt_reset);
        recyclerView = findViewById(R.id.recyclerView);

        //Initialize Database
        database = RoomDB.getInstance(this);

        //Store Database Value in Data List
        dataList = database.Dao().getAll();

        //Initialize Linear Layout Manager
        linearLayoutManager = new LinearLayoutManager(this);

        //Set Layout Manager
        recyclerView.setLayoutManager(linearLayoutManager);

        adapter = new MainAdapter(MainActivity.this, dataList);
        //Set Adapter
        recyclerView.setAdapter(adapter);

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get string from edit text
                String sText = editText.getText().toString().trim();
                //Check Condition
                if (!sText.equals("")) {
                    //When text is not empty
                    //Initialize main data
                    MainData data = new MainData();
                    //Set text on main data
                    data.setText(sText);
                    int notificationId = MyNotificationHandler.addNotification(sText, MainActivity.this);
                    data.setNotId(notificationId);
                    //Insert Data in database
                    database.Dao().insert(data);
                    //Clear Edit Text
                    editText.setText("");
                    //Notify when data is inserted
                    dataList.clear();
                    dataList.addAll(database.Dao().getAll());
                    adapter.notifyDataSetChanged();

                }
            }
        });

        btReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Delete all data from database
                database.Dao().reset(dataList);
                //Notify when all data deleted
                dataList.clear();
                dataList.addAll(database.Dao().getAll());
                adapter.notifyDataSetChanged();
                MyNotificationHandler.removeNotificationChannel(MainActivity.this);
            }
        });

    }


}