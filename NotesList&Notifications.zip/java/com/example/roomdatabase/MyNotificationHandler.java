package com.example.roomdatabase;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

public class MyNotificationHandler {
    public static int addNotification(String description, Context context) {
        //Build notification

        int importance = NotificationManager.IMPORTANCE_HIGH;
        NotificationChannel channel = new NotificationChannel("ToDoChannelID", "ToDoChannel", importance);

        int id = (int) System.currentTimeMillis(); //To add multiple notifications, all the id's must be different

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "ToDoChannelID")
                .setSmallIcon(R.drawable.ic_apptodo_icon)
                .setOngoing(true)
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(description))
                .setContentTitle("To-Do List")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        //Show notification with an intent
        Intent notificationIntent = new Intent(context, MainAdapter.class);
        PendingIntent contentIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        //Add as notification
        NotificationManager notManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notManager.createNotificationChannel(channel);
        notManager.notify(id, builder.build());
        return id;
    }

    public static void cancelNotification(int id, Context context) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.cancel(id);
    }

    public static void removeNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            manager.deleteNotificationChannel("ToDoChannelID");
        }
    }
}
