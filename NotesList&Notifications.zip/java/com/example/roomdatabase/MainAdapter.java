package com.example.roomdatabase;

import android.app.Activity;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;

import android.app.PendingIntent;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.roomdatabase.database.RoomDB;
import com.example.roomdatabase.database.MainData;

import java.util.HashMap;
import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder>{
    //Initialize Variables
    private List<MainData> dataList;
    private Activity context;
    private RoomDB database;


    //Create Constructor
    public MainAdapter(Activity context, List<MainData> dataList) {
        this.context = context;
        this.dataList = dataList;
        notifyDataSetChanged();
    }

    public Context getContext() {
        return this.context;
    }
    @NonNull
    @org.jetbrains.annotations.NotNull
    @Override
    public MainAdapter.ViewHolder onCreateViewHolder(@NonNull @org.jetbrains.annotations.NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row_main, parent, false);

        return new MainAdapter.ViewHolder(view);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        //Initialize Variables
        TextView textView;
        ImageView btEdit, btDelete;
        public ViewHolder(View itemView) {
            super(itemView);
            //Assign Variables
            textView = itemView.findViewById(R.id.textView);
            btEdit = itemView.findViewById(R.id.bt_edit);
            btDelete = itemView.findViewById(R.id.bt_delete);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull @org.jetbrains.annotations.NotNull MainAdapter.ViewHolder holder, int position) {
        //Initialize MainData
        MainData data = dataList.get(position);
        //Initialize Database
        database = RoomDB.getInstance(context);
        //Set Text on TextView
        holder.textView.setText(data.getText());

        holder.btEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Initialize Main Data
                MainData d = dataList.get(holder.getAdapterPosition());
                //Get ID
                int sID = d.getId();
                //Get Text
                String sText = d.getText();

                //Create Dialog
                Dialog dialog = new Dialog(context);
                //Set Content View
                dialog.setContentView(R.layout.dialog_update);
                //Initialize width
                int width = WindowManager.LayoutParams.MATCH_PARENT;
                //Initialize height
                int height = WindowManager.LayoutParams.WRAP_CONTENT;
                //Set Layout
                dialog.getWindow().setLayout(width, height);
                //Show Dialog
                dialog.show();


                //Initialize and assign variables
                EditText editText = dialog.findViewById(R.id.edit_text);
                Button btUpdate = dialog.findViewById(R.id.bt_update);

                editText.setText(sText);

                btUpdate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Dismiss Dialog
                        dialog.dismiss();
                        //Get updated text from edit text
                        String uText = editText.getText().toString().trim();

                        int previousNotificationId = database.Dao().getNotificationId(sID);
                        MyNotificationHandler.cancelNotification(previousNotificationId, getContext());
                        //Update Text in Database


                        database.Dao().update(sID, uText);
                        int newNotificationId = MyNotificationHandler.addNotification(uText, getContext());
                        database.Dao().updateNotId(sID, newNotificationId);
                        //Notify when data is updated
                        dataList.clear();
                        dataList.addAll(database.Dao().getAll());
                        notifyDataSetChanged();


                    }
                });
            }
        });

        holder.btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Initialize main data
                MainData d = dataList.get(holder.getAdapterPosition());
                //Delete text from Database
                MyNotificationHandler.cancelNotification(d.getNotId(), getContext());
                database.Dao().delete(d);
                //Notify when Data is deleted
                int position = holder.getAdapterPosition();
                dataList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, dataList.size());
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}
