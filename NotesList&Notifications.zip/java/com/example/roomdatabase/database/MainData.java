package com.example.roomdatabase.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity (tableName = "data")
public class MainData implements Serializable {
    //Create ID column
    @PrimaryKey (autoGenerate = true)
    private int id;

    //Create Text Column
    @ColumnInfo(name = "text")
    private String text;

    @ColumnInfo(name = "notificationId")
    private int notId;

    public int getNotId() {
        return notId;
    }

    public void setNotId(int notId) {
        this.notId = notId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
