package com.example.roomdatabase.database;

import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@androidx.room.Dao
public interface Dao {
    //Insert Query
    @Insert(onConflict = REPLACE)
    void insert(MainData mainData);

    //Delete Query
    @Delete
    void delete (MainData mainData);

    //Delete All Query
    @Delete
    void reset(List<MainData> mainData);

    //Update Query
    @Query("UPDATE data SET text = :sText WHERE ID = :sID")
    void update(int sID, String sText);

    @Query("UPDATE data SET notificationId = :sNotID WHERE ID = :sID")
    void updateNotId(int sID, int sNotID);

    @Query("SELECT notificationId from data WHERE ID = :sID")
    int getNotificationId(int sID);

    //Get All Data Query
    @Query("SELECT * FROM data")
    List<MainData> getAll();

}
