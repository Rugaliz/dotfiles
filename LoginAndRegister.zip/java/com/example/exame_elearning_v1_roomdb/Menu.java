package com.example.exame_elearning_v1_roomdb;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Menu extends AppCompatActivity {

    String nome;

    private TextView texto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        RoomDB db = RoomDB.getInstance(this);

        //para mandar o id do utilizador para as próximas páginas
        //coloco no setOnClick
        Intent it = this.getIntent();//vai buscar o intent
        nome=it.getStringExtra("nome");
        System.out.println("nome do login:" + nome);

        texto = findViewById(R.id.textView);
        texto.append(nome);

    }
}