package com.example.exame_elearning_v1_roomdb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText et_email, et_password;
    private Button bt_login, bt_registar;

    RoomDB db;
    List<Utilizadores> dataList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = RoomDB.getInstance(this);

        dataList = db.Dao().getAll();

        et_email = findViewById(R.id.et_email);
        et_password = findViewById(R.id.et_password);

        bt_login = findViewById(R.id.bt_login);
        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = et_email.getText().toString().trim();
                String pass = et_password.getText().toString().trim();

                if(verificaRegistro()){
                    int id=db.Dao().validateLogin(email, pass);
                    if(id != -1){

                        Intent it = new Intent(MainActivity.this, Menu.class);
                        it.putExtra("nome",db.Dao().getUsernameID(id));//manda para as outras
                        System.out.println("nome do login:"+db.Dao().getUsernameID(id));

                        startActivity(it);

                    }else {
                        et_password.setText(null);
                        et_email.setText(null);
                        Toast.makeText(MainActivity.this, "Login inválido, tente novamente!.", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        bt_registar = findViewById(R.id.bt_registar);
        bt_registar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(MainActivity.this, Registar.class);
                startActivity(it);
            }
        });



    }

    public boolean verificaRegistro(){

        boolean isValidationSuccessful  = true;

        if(et_email.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(MainActivity.this,"Campo obrigatório, tente novamente!",Toast.LENGTH_SHORT).show();
            isValidationSuccessful = false;
        } else if(et_password.getText().toString().trim().equalsIgnoreCase("")  ){
            Toast.makeText(MainActivity.this,"Campo obrigatório, tente novamente!", Toast.LENGTH_SHORT).show();
            isValidationSuccessful = false;
        }
        return isValidationSuccessful;
    }

}