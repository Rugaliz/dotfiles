package com.example.exame_elearning_v1_roomdb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class Registar extends AppCompatActivity {

    private EditText et_nome, et_email,et_password;
    private Button bt_cancelar,bt_registar;

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$");

    RoomDB db;
    List<Utilizadores> dataList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registar);

        db = RoomDB.getInstance(this);

        dataList = db.Dao().getAll();

        et_nome = findViewById(R.id.et_nome);
        et_email = findViewById(R.id.et_email);
        et_password = findViewById(R.id.et_password);
        et_email.requestFocus();

        bt_cancelar = findViewById(R.id.bt_cancelar);
        bt_cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(Registar.this, MainActivity.class);
                startActivity(it);
            }
        });

        bt_registar = findViewById(R.id.bt_registar);
        bt_registar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail = et_email.getText().toString();
                String nome=et_nome.getText().toString();
                String password=et_password.getText().toString();

                final Utilizadores ut = new Utilizadores();

                ut.setUsername(nome);
                ut.setPassword(password);
                ut.setEmail(mail);

                if(verificaRegistro()){

                    if(db.Dao().getEmail(mail)){ //retorna true se existir na tabela
                        Toast.makeText(Registar.this,"E-mail existente, tente outro!",Toast.LENGTH_SHORT).show();
                    }else{
                        db.Dao().insert(ut);
                        Toast.makeText(Registar.this,"E-mail registado!",Toast.LENGTH_SHORT).show();
                        Intent it = new Intent(Registar.this, MainActivity.class);
                        startActivity(it);
                    }

                }

            }
        });

    }

    public boolean verificaRegistro(){

        boolean isValidationSuccessful  = true;

        if(et_nome.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(Registar.this,"Campo obrigatório, tente novamente!",Toast.LENGTH_SHORT).show();
            isValidationSuccessful = false;
        } else if(et_email.getText().toString().trim().equalsIgnoreCase("")  ){
            Toast.makeText(Registar.this,"Campo obrigatório, tente novamente!", Toast.LENGTH_SHORT).show();
            isValidationSuccessful = false;
        } else if(et_password.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(Registar.this,"Campo obrigatório, tente novamente!", Toast.LENGTH_SHORT).show();
            isValidationSuccessful = false;
        }else if(!validaEmail()){
            isValidationSuccessful = false;
        }
        return isValidationSuccessful;
    }

    public boolean validaEmail() {
        String mailInput = et_email.getText().toString().trim();

        if (mailInput.isEmpty()) {
            et_email.setError("Campo obrigatório, tente novamente!");
            return false;
        } else if (!(EMAIL_PATTERN.matcher(mailInput).matches())) {
            et_email.setError("E-mail inválido, tente novamente (exemplo@exemplo.com)!");
            return false;
        } else {
            et_email.setError(null);
            return true;
        }
    }

}