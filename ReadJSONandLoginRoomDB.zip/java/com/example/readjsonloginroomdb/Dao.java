package com.example.readjsonloginroomdb;

import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@androidx.room.Dao
public interface Dao {
    //Insert Query
    @Insert(onConflict = REPLACE)
    void insert(Utilizadores users);

    //Delete Query
    @Delete
    void delete (Utilizadores users);

    //Delete All Query
    @Delete
    void reset(List<Utilizadores> userList);

    //Update Query
    @Query("UPDATE users SET username = :newUserame WHERE ID = :sID")
    void updateUsername(int sID, String newUserame);

    @Query("UPDATE users SET password = :newPassword WHERE ID = :sID")
    void updatePassword(int sID, String newPassword);

    @Query("UPDATE users SET email = :newEmail WHERE ID = :sID")
    void updateEmail(int sID, String newEmail);

    //Get Query
    @Query("SELECT username from users WHERE ID = :sID")
    String getUsernameID(int sID);

    @Query("SELECT * from users WHERE email = :sEmail")
    boolean getEmail(String sEmail);

    @Query("SELECT * from users WHERE email = :sEmail AND password= :sPassword")
    List<Utilizadores> validateLogin(String sEmail, String sPassword);

    //Get All Data Query
    @Query("SELECT * FROM users")
    List<Utilizadores> getAll();

}
