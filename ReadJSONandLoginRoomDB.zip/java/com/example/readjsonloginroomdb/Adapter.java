package com.example.readjsonloginroomdb;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter <Adapter.AdapterViewHolder> {

    private ArrayList<String> mParques = new ArrayList<String>();
    private Context context;
    private JSONArray js;

    public Adapter(Context context, JSONArray js) {
        this.context = context;
        this.js = js;

    }

    public class AdapterViewHolder extends RecyclerView.ViewHolder{
        public final TextView mParquesTV, id, description;
        public final ImageView iv_imagem;

        public AdapterViewHolder(@NonNull View itemView) {
            super(itemView);
            mParquesTV = (TextView) itemView.findViewById(R.id.tv);
            iv_imagem = itemView.findViewById(R.id.iv_imagem);
            id = itemView.findViewById(R.id.id);
            description = itemView.findViewById(R.id.description);
        }
    }

    @Override
    public AdapterViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context con = parent.getContext();
        int layout = R.layout.activity_adapter;
        LayoutInflater inflater = LayoutInflater.from(con);
        boolean attachToParent = false;

        View view = inflater.inflate(layout, parent, attachToParent);
        return new AdapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AdapterViewHolder holder, final int position) {

        try {
            final JSONObject obj = js.getJSONObject(position);

            holder.mParquesTV.setText(obj.getString("name"));
            holder.id.setText(obj.getString("id"));
            holder.description.setText(obj.getString("description"));

            //para colocar imagens no recyclerview
            System.out.println("ref:"+obj.get("ref"));
            new DownloadImageTask(holder.iv_imagem).execute(obj.getString("ref"));

            holder.iv_imagem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent= new Intent(context, AtividadeSecundaria.class);
                    intent.putExtra("dados",obj.toString());
                    intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        if(js != null){
            return js.length();
        }
        return 0;
    }

    public void addItem(String parques) {
        //mParques = parques;
        mParques.add(parques);
        notifyDataSetChanged();
    }

    public class ForecastAdapterViewHolder extends RecyclerView.ViewHolder {
        public ForecastAdapterViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap icon = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                icon = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return icon;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }

}

