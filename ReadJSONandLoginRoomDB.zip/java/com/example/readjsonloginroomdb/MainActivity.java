package com.example.readjsonloginroomdb;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {

    private String[] parques;
    private Button bt_semParametros;
    private ProgressDialog pd;
    private RecyclerView mRecyclerView;
    private Adapter mForecastAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //RecycleView
        mRecyclerView = findViewById(R.id.recicler);
        LinearLayoutManager layoutManager
                = new LinearLayoutManager
                ( this , LinearLayoutManager . VERTICAL , false ) ;
        mRecyclerView.setLayoutManager ( layoutManager ) ;
        mRecyclerView.setHasFixedSize( true ) ;
        //mForecastAdapter = new Adapter(getApplicationContext());
        //mRecyclerView . setAdapter ( mForecastAdapter ) ;
        //-------------------------------------------
        //procura sem os parametros
        bt_semParametros = findViewById(R.id.bt_pesquisarSemParametros);
        bt_semParametros.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new JsonTask().execute("http://estga-prog.ua.pt/dadm/json/epNDADM1819.json");
                //new JsonTask().execute("http://192.168.1.178/testeDADM/exemploDADM.json"); //o meu servidor
            }
        });
    }

    private void setRV(JSONArray json){
        Adapter adp = new Adapter(getApplicationContext(), json);
        mRecyclerView.setAdapter(adp);
    }

    private class JsonTask extends AsyncTask<String, String, String>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(MainActivity.this);
            pd.setMessage("A obter dados, aguarde por favor.");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected void onPostExecute(String responde) {
            if(responde != null){
                try{
                    JSONArray json = new JSONArray(responde);
                    parques = new String[json.length()];
                    setRV(json);
                }catch (JSONException ex){
                    Log.e("App","Failure",ex);
                }
            }else{
                mForecastAdapter.addItem("Resposta vazia!");
            }
            if(pd.isShowing()){
                pd.dismiss();
            }
        }

        @Override
        protected String doInBackground(String... params) {
            URLConnection urlConn = null;
            BufferedReader bufferedReader = null;

            try{
                URL url = new URL(params[0]);
                urlConn = url.openConnection();
                bufferedReader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));

                StringBuffer stringBuffer = new StringBuffer();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    stringBuffer.append(line);
                }

                return stringBuffer.toString();

            }catch (Exception e){
                Log.e("App","JsonTask", e);
                return null;
            }finally {
                if(bufferedReader != null){
                    try{
                        bufferedReader.close();
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                }
            }
        }
    }


}

