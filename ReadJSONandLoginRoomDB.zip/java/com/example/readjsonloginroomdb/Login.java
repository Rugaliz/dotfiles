package com.example.readjsonloginroomdb;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Login extends AppCompatActivity {

    EditText et_mail;
    EditText et_password;
    Button bt_login;
    Button bt_registar;
    RoomDB db;
    List<Utilizadores> dataList = new ArrayList<>();
    private ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = RoomDB.getInstance(this);

        dataList = db.Dao().getAll();

        et_mail = findViewById(R.id.et_mail);
        et_mail.requestFocus();
        et_password = findViewById(R.id.et_password);
        bt_login = findViewById(R.id.bt_login);
        bt_registar = findViewById(R.id.bt_registar);

        bt_registar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(Login.this, Registar.class);
                startActivity(it);
            }
        });

        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utilizadores ut = new Utilizadores();
                String mail = et_mail.getText().toString();
                String password = et_password.getText().toString();

                dataList = db.Dao().validateLogin(mail, password);

                if (dataList.size() != 0) {
                    Toast.makeText(Login.this, "Login efetuado!.", Toast.LENGTH_SHORT).show();
                    Intent it = new Intent(Login.this, MainActivity.class);
                    startActivity(it);
                } else {
                    et_password.setText(null);
                    et_mail.setText(null);
                    Toast.makeText(Login.this, "Login inválido, tente novamente!.", Toast.LENGTH_SHORT).show();
                }
            }

        });

    }

}