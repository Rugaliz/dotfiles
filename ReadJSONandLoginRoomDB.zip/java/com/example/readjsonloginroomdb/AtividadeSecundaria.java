package com.example.readjsonloginroomdb;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;

public class AtividadeSecundaria extends AppCompatActivity {
    String dados;
    ImageView iv_imagem;
    TextView tv_dados, tv_id, tv_description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atividade_secundaria);

        Intent it = this.getIntent();//vai buscar o intent
        dados=it.getStringExtra("dados");
        System.out.println("id historico:"+dados);

        iv_imagem=findViewById(R.id.iv_imagem);

        tv_dados = findViewById(R.id.tv_name);
        tv_id=findViewById(R.id.tv_id);
        tv_description=findViewById(R.id.tv_description);


        try {
            JSONObject job = new JSONObject(dados);
            new DownloadImageTask(iv_imagem).execute(job.getString("ref"));
            tv_dados.setText("Nome:"+job.getString("name"));
            tv_id.setText("Id:"+job.getString("id"));
            tv_description.setText("Description"+job.getString("description"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap icon = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                icon = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return icon;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }

}