package com.example.readjsonloginroomdb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class Registar extends AppCompatActivity {

    EditText et_username, et_password1, et_mail;
    Button bt_registar, bt_cancelar;
    RoomDB db;
    List<Utilizadores> dataList = new ArrayList<>();

    String nome, mail, pass1;

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registar);

        db = RoomDB.getInstance(this);

        dataList = db.Dao().getAll();

        et_password1 = findViewById(R.id.et_password);
        et_username = findViewById(R.id.et_username);
        et_mail = findViewById(R.id.et_mail);
        et_mail.requestFocus();
        bt_registar = findViewById(R.id.bt_registar);
        bt_cancelar = findViewById(R.id.bt_cancelar);


        bt_cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(Registar.this, Login.class);
                startActivity(it);
            }
        });

        bt_registar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nome = et_username.getText().toString();
                mail = et_mail.getText().toString();
                pass1 = et_password1.getText().toString();

                final Utilizadores ut = new Utilizadores();

                ut.setPassword(pass1);
                ut.setUsername(nome);
                ut.setEmail(mail);

                if (verificaRegistro()) {
                    if (db.Dao().getEmail(mail)) {//se for true existe
                        Toast.makeText(Registar.this,"CEmail existente, tente novamente!",Toast.LENGTH_SHORT).show();
                    }else{
                        db.Dao().insert(ut);
                        Intent it = new Intent(Registar.this, Login.class);
                        startActivity(it);
                    }
                }
            }
        });

    }

    public boolean verificaRegistro(){

        boolean isValidationSuccessful  = true;

        if(et_username.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(Registar.this,"Campo obrigatório, tente novamente!",Toast.LENGTH_SHORT).show();
            isValidationSuccessful = false;
        } else if(et_mail.getText().toString().trim().equalsIgnoreCase("")  ){
            Toast.makeText(Registar.this,"Campo obrigatório, tente novamente!", Toast.LENGTH_SHORT).show();
            isValidationSuccessful = false;
        } else if(et_password1.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(Registar.this,"Campo obrigatório, tente novamente!", Toast.LENGTH_SHORT).show();
            isValidationSuccessful = false;
        }else if(!validaEmail()){
            Toast.makeText(Registar.this,"Campo email inválido, tente novamente!",Toast.LENGTH_SHORT).show();
            isValidationSuccessful = false;
        }
        return isValidationSuccessful;
    }

    //validar entrada
    public boolean validaEmail() {
        String mailInput = et_mail.getText().toString().trim();

        if (mailInput.isEmpty()) {
            et_mail.setError("Campo obrigatório, tente novamente!");
            return false;
        } else if (!(EMAIL_PATTERN.matcher(mailInput).matches())) {
            et_mail.setError("E-mail inválido, tente novamente (exemplo@exemplo.com)!");
            return false;
        } else {
            et_mail.setError(null);
            return true;
        }
    }
}