package com.example.fichaex2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button listar, criar;
    veiculoDao dao;
    DB db;
    entity entitity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listar = findViewById(R.id.list);
        criar = findViewById(R.id.cria);





        listar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ListaVeiculo.class);
                startActivity(intent);
                finish();
            }
        });
        criar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(MainActivity.this,Criaveiculo.class);
                startActivity(intent2);
                finish();
            }
        });
    }




}