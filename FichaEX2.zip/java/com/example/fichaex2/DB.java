package com.example.fichaex2;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

    @Database(entities = {entity.class}, version = 1)
    public abstract class DB extends RoomDatabase {
        public abstract veiculoDao veiculoDao();

        private static DB database;

        public synchronized static DB getInstance(Context context) {
            if (database == null) {
                database = Room.databaseBuilder(context.getApplicationContext(), DB.class, "automoveis").allowMainThreadQueries()
                        .fallbackToDestructiveMigration()
                        .build();
            }
            return database;
        }
    }

