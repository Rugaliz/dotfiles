package com.example.fichaex2;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


    @Entity(tableName = "entity")
    public class entity{
        @PrimaryKey(autoGenerate = true)
        public int id;

        @ColumnInfo(name = "Marca")
        public String marca;

        @ColumnInfo(name = "Modelo")
        public String modelo;

        @ColumnInfo(name = "Ano")
        public String ano;

        @ColumnInfo(name = "Matricula")
        public String matricula;

        public void setId(int id) {
            this.id = id;
        }

        public void setMarca(String marca) {
            this.marca = marca;
        }

        public void setModelo(String modelo) {
            this.modelo = modelo;
        }

        public void setAno(String ano) {
            this.ano = ano;
        }

        public void setMatricula(String matricula) {
            this.matricula = matricula;
        }

        public int getId() {
            return id;
        }

        public String getMarca() {
            return marca;
        }

        public String getModelo() {
            return modelo;
        }

        public String getAno() {
            return ano;
        }

        public String getMatricula() {
            return matricula;
        }

        @Override
        public String toString() {
            return "entity{" +
                    "id=" + id +
                    ", marca='" + marca + '\'' +
                    ", modelo='" + modelo + '\'' +
                    ", ano='" + ano + '\'' +
                    ", matricula='" + matricula + '\'' +
                    '}';
        }
    }
















