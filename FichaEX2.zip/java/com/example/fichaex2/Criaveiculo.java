package com.example.fichaex2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class Criaveiculo extends AppCompatActivity {
    Button criaVeiculo;
    EditText matricula,marca,modelo, ano;
    DB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criaveiculo);

        criaVeiculo = findViewById(R.id.criarveiculo);
        matricula = findViewById(R.id.matricula);
        marca = findViewById(R.id.marca);
        modelo = findViewById(R.id.modelo);
        ano = findViewById(R.id.ano);

        db = DB.getInstance(this);

        criaVeiculo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adicionaVeiculo();
                Toast.makeText(Criaveiculo.this,"Criei",Toast.LENGTH_SHORT).show();
                Intent it = new Intent(Criaveiculo.this,MainActivity.class);
                startActivity(it);
                finish();
            }
        });

    }

    public void adicionaVeiculo(){
            entity en = new entity();

            en.setAno(ano.getText().toString());
            en.setMarca(marca.getText().toString());
            en.setMatricula(matricula.getText().toString());
            en.setModelo((modelo.getText().toString()));
    try {
            db.veiculoDao().insertAll(en);
    }catch (Exception ex){
        Log.d("teste",ex.toString());
    }

        try {
            List<entity> dbinfo = db.veiculoDao().getAll();
            Log.d("teste",dbinfo.toString());
        }catch (Exception ex){
            Log.d("teste",ex.toString());
        }




    }
}