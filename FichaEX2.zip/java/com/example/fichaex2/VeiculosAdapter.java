package com.example.fichaex2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Constructor;
import java.util.List;

public class VeiculosAdapter extends RecyclerView.Adapter<VeiculosAdapter.VeiculoViewHolder> {

    private List<entity> entities;

    public VeiculosAdapter(List<entity> entities) {

        this.entities = entities;
    }



    @NonNull
    @Override
    public VeiculoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        int layoutForListItem = R.layout.item;
        LayoutInflater inflater = LayoutInflater.from(context);
        boolean shouldAttachToParentImmediately = false;
        View view = inflater.inflate(layoutForListItem, parent, shouldAttachToParentImmediately);
        VeiculoViewHolder pvh = new VeiculoViewHolder(view);

        return pvh;
    }

    @Override
    public void onBindViewHolder(@NonNull VeiculoViewHolder holder, int position) {
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return entities.size();
    }



    public class VeiculoViewHolder extends RecyclerView.ViewHolder {
        TextView matricula,marca;
        public VeiculoViewHolder(@NonNull View itemView) {
            super(itemView);
            itemView.setOnClickListener((v -> {
                Context context = v.getContext();
                int pos = getAdapterPosition();
            }));
            matricula = itemView.findViewById(R.id.matricula);
            marca = itemView.findViewById(R.id.marca);
        }

        public void bind(int veiculosIndex){
            matricula.setText(entities.get(veiculosIndex).getMatricula());
            marca.setText(entities.get(veiculosIndex).getMarca());
        }

    }
}


