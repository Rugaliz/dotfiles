package com.example.fichaex2;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Entity;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;



    @Dao
    public interface veiculoDao{
        @Query("SELECT * FROM entity")
        List<entity> getAll();

        @Query("SELECT * FROM entity WHERE id IN (:userIds)")
        List<entity> loadAllByIds(int[] userIds);


        @Query("SELECT * FROM entity WHERE Matricula LIKE :matriculas LIMIT 1")
        entity findByName(String matriculas);

        @Query("UPDATE entity SET Matricula = :matricula WHERE ID = :sID")
        void updateNotId(int sID, int matricula);

        @Insert
        void insertAll(entity... entities);

        @Delete
        void delete(entity entity);
    }

