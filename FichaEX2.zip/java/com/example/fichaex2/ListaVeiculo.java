package com.example.fichaex2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.List;

public class ListaVeiculo extends AppCompatActivity {

    RecyclerView rv;
    DB db;
    Button voltar;
    List<entity>entities;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_veiculo);
        voltar = findViewById(R.id.bt_return);
        rv = findViewById(R.id.recycler);
        db = DB.getInstance(this);
        entities = db.veiculoDao().getAll();
        Log.d("test2",entities.toString());

        VeiculosAdapter v = new VeiculosAdapter(entities);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ListaVeiculo.this);
        rv.setLayoutManager(linearLayoutManager);
        rv.setHasFixedSize(true);
        rv.setAdapter(v);


        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(ListaVeiculo.this,MainActivity.class);
                startActivity(it);
                finish();
            }
        });

    }




}