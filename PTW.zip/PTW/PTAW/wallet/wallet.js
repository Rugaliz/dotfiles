// Datatable variables
let table = document.getElementById("wallet_datatable");
let filter = document.getElementById("table_filters");
let dataSet = [];
var datatable;
var cripto_length;
var deposits_length;

// Graph variables
var investment_cripto = 0;
var investment_deposits = 0;
var balance_cripto = 0;
var balance_deposits = 0;

var today = new Date().toISOString().split('T')[0];
document.getElementById("wallet_data").setAttribute('max', today);

// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
    'use strict'

    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')

    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
        .forEach(function(form) {
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }

                form.classList.add('was-validated')
            }, false)
        })
})();


// Graph
async function getDataGraph() {
    let xhr = new XMLHttpRequest();
    xhr.responseType = 'json';

    // 4. This function will be called after the response is received from the server
    xhr.onload = async function() {
        if (xhr.status == 200) {
            if (xhr.response.erro !== "none") {
                window.alert(xhr.response.erro);
            } else if (xhr.response.length == 0) {
                window.alert("Este utilizador não tens dados registados na aplicação");
            } else {

                xhr.response.cripto.forEach(element => {
                    if (element.sum_cripto != null)
                        investment_cripto = parseFloat(element.sum_cripto);
                });

                xhr.response.deposits.forEach(element => {
                    if (element.sum_deposits != null)
                        investment_deposits = parseFloat(element.sum_deposits);
                });

                init_morris_charts();

            }

        } else {
            window.alert("Erro" + xhr.status + ": " + xhr.statusText);
        }
    };

    // 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
    xhr.open("GET", './php/wallet/graph.php', true);
    // 3. Send the request to the server
    xhr.send();
}

function init_morris_charts() {
    if (typeof(Morris) === 'undefined') { return; }

    let data;
    let result_cripto = (balance_cripto - investment_cripto).toFixed(2);
    let result_deposits = (balance_deposits - investment_deposits).toFixed(2);

    if (investment_cripto == 0 && investment_deposits == 0) {
        data = [{ x: 'Não existem investimentos' }];
    } else if (investment_cripto == 0) {
        // data = [{ x: 'Depósitos', y: investment_deposits, z: result_deposits, s: balance_deposits }];
        data = [
            { x: 'Cripto Moedas', y: 0, z: 0, s: 0 },
            { x: 'Depósitos', y: investment_deposits, z: result_deposits, s: balance_deposits }
        ]
    } else if (investment_deposits == 0) {
        data = [{ x: 'Cripto Moedas', y: investment_cripto, z: result_cripto, s: balance_cripto }];
        data = [
            { x: 'Cripto Moedas', y: investment_cripto, z: result_cripto, s: balance_cripto },
            { x: 'Depósitos', y: 0, z: 0, s: 0 }
        ]
    } else {
        data = [
            { x: 'Cripto Moedas', y: investment_cripto, z: result_cripto, s: balance_cripto },
            { x: 'Depósitos', y: investment_deposits, z: result_deposits, s: balance_deposits }
        ]
    }

    document.getElementById("wallet_balance").innerHTML = (balance_cripto + balance_deposits).toFixed(2) + "$";

    if ($('#graphx').length) {

        Morris.Bar({
            element: 'graphx',
            data,
            xkey: 'x',
            ykeys: ['s', 'y', 'z'],
            barColors: ['#63666A', '#489FDF', '#BEC6C4', '#6AD1E3'],
            hideHover: 'auto',
            labels: ['Saldo', 'Investido', 'Lucro'],
            resize: true
        }).on('click', function(i, row) {
            console.log(i, row);
        });
    }
}

// \Graph

// Datatable

filter.addEventListener("change", async function() {
    if (filter.value == 'cripto') {
        datatable.clear()
            .draw();
        await createTable('./php/wallet/getInvestmentCripto.php', 'cripto');
    } else if (filter.value == 'deposits') {
        datatable.clear()
            .draw();
        await createTable('./php/wallet/getInvestmentDeposit.php', 'deposit');
    } else {
        datatable.clear()
            .draw();
        await createTable('./php/wallet/getInvestmentCripto.php', 'cripto');
        await createTable('./php/wallet/getInvestmentDeposit.php', 'deposit');
    }
});

async function createTable(filter, type) {
    // 1. Create a new XMLHttpRequest object
    let xhr = new XMLHttpRequest();
    xhr.responseType = 'json';

    // 4. This function will be called after the response is received from the server
    xhr.onload = async function() {
        if (xhr.status == 200) {
            if (xhr.response.erro !== "none") {
                window.alert(xhr.response.erro);
            } else if (xhr.response.length == 0) {
                window.alert("Este utilizador não tens dados registados na aplicação");
            } else {

                if (type == 'cripto')
                    cripto_length = xhr.response.data.length;
                else
                    deposits_length = xhr.response.data.length;

                await setData(xhr.response.data, type);
            }

        } else {
            window.alert("Erro" + xhr.status + ": " + xhr.statusText);
        }
    };

    // 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
    xhr.open("GET", filter, true);
    // 3. Send the request to the server
    xhr.send();
}

var i = 0,
    j = 0;

async function setData(data, type) {
    for (let element of data) {
        let obj = [];

        if (type == 'cripto') {
            obj.push('<div class= "cryptoTableImagem"><img src = "./icons/cripto.png"></img>1</div>');
            obj.push(element.name);
            //calculate balence now
            let response = await fetch(element.api);
            let cripto = await response.json();
            let criptoCurrentPrice = cripto.data.priceUsd;
            let money_now = criptoCurrentPrice * element.moeda_quantidade;
            obj.push(parseFloat(money_now).toFixed(2));

            balance_cripto = balance_cripto + money_now;

            //calculate change from the beginning of the investment
            let alteration = parseFloat(((money_now - element.dinheiro_investido) / element.dinheiro_investido) * 100 + "%").toFixed(1)
            if (alteration < 0)
                obj.push('<div style="color: red; ">' + alteration + "%" + '</div>');
            else if (alteration > 0)
                obj.push('<div style="color: green; ">' + alteration + "%" + '</div>');
            else
                obj.push(alteration + "%");


            obj.push(element.data);

            i++;

            datatable.row.add(obj).node().id = "c" + element.id;

            datatable.draw(false);

        } else {
            obj.push('<div class= "cryptoTableImagem"><img src = "./icons/depositos.png"></img>2</div>');
            obj.push(element.name);

            let today = new Date();
            let year = today.getFullYear() - new Date(element.data_inicio).getFullYear();
            let result;

            if (element.periodo == "Trimestral") {
                result = parseFloat(element.invest_deposits) + (((parseFloat(element.juro.split("%")[0]) * element.invest_deposits) * 3) * parseInt(year));
            } else if (element.periodo == "Semestral") {
                result = parseFloat(element.invest_deposits) + (((parseFloat(element.juro.split("%")[0]) * element.invest_deposits) * 2) * parseInt(year));
            } else {
                result = parseFloat(element.invest_deposits) + ((parseFloat(element.juro.split("%")[0]) * element.invest_deposits) * parseInt(year));
            }
            obj.push(result.toFixed(2));

            balance_deposits = balance_deposits + result;

            let alteration = ((result - parseFloat(element.invest_deposits)) / parseFloat(element.invest_deposits)) * 100;

            if (alteration < 0)
                obj.push('<div style="color: red; ">' + alteration.toFixed(2) + "%" + '</div>');
            else if (alteration > 0)
                obj.push('<div style="color: green; ">' + alteration.toFixed(2) + "%" + '</div>');
            else
                obj.push(alteration.toFixed(2) + "%");

            obj.push(element.data_inicio);

            j++;

            datatable.row.add(obj).node().id = "d" + element.id;

            datatable.draw(false);
        }
    }

    if (i == cripto_length && j == deposits_length) {
        getDataGraph();
    }
}

function table_inicialize() {
    datatable = $('#wallet_datatable').DataTable({
        data: dataSet,
        columns: [
            { title: 'Tipo <i class="fa fa-info-circle" aria-hidden="true" title="Tipo de investimento"></i>' },
            { title: 'Nome <i class="fa fa-info-circle" aria-hidden="true" title="Nome do investimento"></i>' },
            { title: 'Saldo <i class="fa fa-info-circle" aria-hidden="true" title="Saldo atual do investimento"></i>' },
            { title: 'Alteração <i class="fa fa-info-circle" aria-hidden="true" title="Variação do saldo do investimento"></i>' },
            { title: 'Data de Investimento <i class="fa fa-info-circle" aria-hidden="true" title="Data do registo do investimento"></i>' },
            {
                title: '<i class="fa fa-info-circle" aria-hidden="true" title="Editar investimento"></i>',
                data: null,
                className: "dt-center editor-edit",
                defaultContent: '<i class="fa fa-pencil"/>',
                orderable: false
            },
            {
                title: '<i class="fa fa-info-circle" aria-hidden="true" title="Terminar investimento"></i>',
                data: null,
                className: "dt-center editor-delete",
                defaultContent: '<i class="fa fa-trash"/>',
                orderable: false
            }
        ]
    });

    var id;
    datatable.on('click', 'tr', function() {
        id = this.id;
        // alert("edit: " + id);

    });

    datatable.on('click', 'td.editor-edit', function(e) {
        setTimeout(function() {
            let type_id = id.charAt(0);

            if (type_id == 'c')
                edit_row_table_cripto(id.substring(1));
            else
                edit_row_table_deposits(id.substring(1));

        }, 50);
    });


    // Delete a record
    datatable.on('click', 'td.editor-delete', function(e) {
        setTimeout(function() {
            delete_row_table(this, id);
        }, 50);
    });

    createTable('./php/wallet/getInvestmentCripto.php', 'cripto');

    createTable('./php/wallet/getInvestmentDeposit.php', 'deposit');

}

function edit_row_table_cripto(id) {
    // alert("edit: " + id);

    let quantidadeMoeda = document.getElementById("wallet_quantidadeMoeda");
    let valorInvestido = document.getElementById("wallet_valorInvestimento");
    let precoMoeda = document.getElementById("wallet_precoMoeda");
    let date = document.getElementById("wallet_data");
    let invest_id = document.getElementById("wallet_id_cripto");

    let xhrGetCripto = new XMLHttpRequest();
    xhrGetCripto.responseType = 'json';
    // 4. This function will be called after the response is received from the server
    xhrGetCripto.onload = function() {
        if (xhrGetCripto.status == 200) {
            if (xhrGetCripto.response.erro !== "none") {
                window.alert(xhrGetCripto.response.erro);
            } else if (xhrGetCripto.response.data.length == 0) {
                window.alert("Este Investimento não tem conteudo");
            } else {
                let investmentData = xhrGetCripto.response.data[0];

                quantidadeMoeda.value = investmentData.moeda_quantidade;
                valorInvestido.value = investmentData.dinheiro_investido;
                precoMoeda.value = investmentData.moeda_valor_compra;
                date.value = investmentData.data;
                invest_id.value = id;

                console.log("id: " + id);

                $("#wallet_edit_row_cripto").modal('show');
            }

        } else {
            window.alert("Erro" + xhrGetCripto.status + ": " + xhrGetCripto.statusText);
        }
    };

    // 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
    xhrGetCripto.open("GET", './php/wallet/getCripto.php?investment=' + id, true);
    // 3. Send the request to the server
    xhrGetCripto.send();
}

function edit_row_table_deposits(id) {
    // alert("id: " + id);

    let quantidade = document.getElementById("wallet_invest");
    let juro = document.getElementById("wallet_juro");
    let taxacao = document.getElementById("wallet_taxacao");
    let prazo = document.getElementById("wallet_prazo");
    let date = document.getElementById("wallet_data_deposits");
    let invest_id = document.getElementById("wallet_id_deposits");

    let xhrGetDeposits = new XMLHttpRequest();
    xhrGetDeposits.responseType = 'json';
    // 4. This function will be called after the response is received from the server
    xhrGetDeposits.onload = function() {
        if (xhrGetDeposits.status == 200) {
            if (xhrGetDeposits.response.erro !== "none") {
                window.alert(xhrGetDeposits.response.erro);
            } else if (xhrGetDeposits.response.data.length == 0) {
                window.alert("Este Investimento não tem conteudo");
            } else {
                let investmentData = xhrGetDeposits.response.data[0];

                quantidade.value = investmentData.dinheiro_investido;
                juro.value = investmentData.juro.substring(0, investmentData.juro.length - 1);
                taxacao.value = investmentData.periodo_taxacao;
                prazo.value = investmentData.prazo;
                date.value = investmentData.data_inicio;
                invest_id.value = id;

                $("#wallet_edit_row_deposits").modal('show');
            }

        } else {
            window.alert("Erro" + xhrGetDeposits.status + ": " + xhrGetDeposits.statusText);
        }
    };

    // 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
    xhrGetDeposits.open("GET", './php/wallet/getDeposits.php?investment=' + id, true);
    // 3. Send the request to the server
    xhrGetDeposits.send();



}

function delete_row_table(t, id) {
    // alert("delete: " + id);
    $("#wallet_delete_row").modal('show');

    let button = document.getElementById("wallet_delete_row_popup");
    let type_id = id.charAt(0);
    let num_id = id.substring(1);

    button.addEventListener("click", function() {

        $.post("./php/wallet/deleteInvestment.php", {
                type_id: type_id,
                num_id: num_id
            },
            function(data, status) {
                if (status == "success") {
                    $("#wallet_delete_row").modal('hide');

                    datatable.row("#" + id).remove().draw();
                    document.location.href = "./wallet.php";
                    //window.alert("Investimento alterado com sucesso!");
                } else {
                    window.alert("Erro: " + status);
                }
            });
    });
}

// \Datatable

$(document).ready(function() {
    table_inicialize();
});