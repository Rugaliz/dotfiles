var userName = document.getElementById("settings_userName");
var userEmail = document.getElementById("settings_userEmail");
var userAddress = document.getElementById("settings_userAddress");
var userBirthday = document.getElementById("settings_userBirthday");
var userPhone = document.getElementById("settings_userPhone");
var boxPass1 = document.getElementById("settings_box_pass1");
var boxPass2 = document.getElementById("settings_box_pass2");
var currentPass = document.getElementById("settings_changePass_current_pass");
var currentPassText;

var today = new Date().toISOString().split('T')[0];
document.getElementById("settings_userBirthday").setAttribute('max', today);

userName.addEventListener("input", function () {
    $("#saveUserSpecs").css("display", "block");
});
userEmail.addEventListener("input", function () {
    $("#saveUserSpecs").css("display", "block");
});
userAddress.addEventListener("input", function () {
    $("#saveUserSpecs").css("display", "block");
});
userBirthday.addEventListener("input", function () {
    $("#saveUserSpecs").css("display", "block");
});
userPhone.addEventListener("input", function () {
    $("#saveUserSpecs").css("display", "block");
});

function get_user_data() {
    // 1. Create a new XMLHttpRequest object
    let xhr = new XMLHttpRequest();
    xhr.responseType = 'json';
    // 4. This function will be called after the response is received from the server
    xhr.onload = function () {
        if (xhr.status == 200) {
            if (xhr.response.erro !== "none") {
                window.alert(xhr.response.erro);
            } else if (xhr.response.data.length == 0) {
                window.alert("Este utilizador não tens dados registados na aplicação");
            } else {
                userName.value = xhr.response.data[0].nome;
                userEmail.value = xhr.response.data[0].email;
                userAddress.value = xhr.response.data[0].morada;
                userBirthday.value = xhr.response.data[0].data_nascimento;
                userPhone.value = xhr.response.data[0].telemovel;
                currentPassText = xhr.response.data[0].pass;
            }

        } else {
            window.alert("Erro" + xhr.status + ": " + xhr.statusText);
        }
    };

    // 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
    xhr.open("GET", './php/settings/getUserData.php', true);
    // 3. Send the request to the server
    xhr.send();
}

// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
    'use strict'

    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')

    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }

                form.classList.add('was-validated')
            }, false)
        })
})();

function get_current_pass() {
    get_user_data();

    let passEncrypt;

    currentPass.addEventListener("input", function () {
        $.post("./php/settings/encryptPass.php", {
            pass: currentPass.value
        },
            function (data, status) {
                if (status == "success") {
                    passEncrypt = data;
                } else {
                    window.alert("Erro: " + status);
                }
            });

        setTimeout(function () {
            // console.log("as: " + passEncrypt + ", " + currentPassText);
            if (passEncrypt == currentPassText) {
                boxPass1.style.display = "block";
                boxPass2.style.display = "block";
                $("#settings_changePass_current_pass").prop('disabled', true);
                $("#settings_changePass_save").prop('disabled', false);
            }
        }, 100);



    });

}

function change_pass() {
    let pass1 = document.getElementById("settings_changePass_pass1");
    let pass2 = document.getElementById("settings_changePass_pass2");
    let showErro1 = document.getElementById("settings_changePass_erro1");
    let showErro2 = document.getElementById("settings_changePass_erro2");

    if (pass1.value.length == 0 || pass2.value.length == 0) {
        showErro1.style.display = "block";
        showErro2.style.display = "block";
        return;
    }

    if (pass1.value == pass2.value) {

        $.post("./php/settings/changePass.php", {
            pass1: pass1.value,
            pass2: pass2.value
        },
            function (data, status) {
                if (status == "success") {

                    $('#settings_change_pass_popUp').modal('hide');
                    setTimeout(function () {
                        alert("Password alterada com sucesso!");
                        pass1.value = "";
                        pass2.value = "";
                        showErro1.style.display = "none";
                        showErro2.style.display = "none";
                        boxPass1.style.display = "none";
                        boxPass2.style.display = "none";
                        $("#settings_changePass_current_pass").prop('disabled', false);
                        currentPass.value = "";
                    }, 100);
                } else {
                    window.alert("Erro: " + status);
                }
            });


    } else {
        window.alert("Por favor, insira a mesma password");
    }
}

function delete_user() {

    let btn_confirm = document.getElementById("settings_delete_popup_confirm");

    btn_confirm.onclick = function () {
        $('#settings_delete_popUp').modal('hide');

        // 1. Create a new XMLHttpRequest object
        let deleteUser = new XMLHttpRequest();
        deleteUser.responseType = 'json';
        // 4. This function will be called after the response is received from the server
        deleteUser.onload = function () {
            if (deleteUser.status == 200) {
                if (deleteUser.response.erro !== "none") {
                    window.alert(deleteUser.response.erro);
                } else {
                    window.location.href = "./login.php";
                }
            } else {
                window.alert("Erro" + deleteUser.status + ": " + deleteUser.statusText);
            }
        };

        // 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
        deleteUser.open("GET", './php/settings/deleteUser.php', true);
        // 3. Send the request to the server
        deleteUser.send();
    }
}

$(document).ready(function () {
    get_user_data();
});