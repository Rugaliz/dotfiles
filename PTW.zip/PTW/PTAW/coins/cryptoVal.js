const coins = [
    [
        "Bcoin",
        "BcoinN",
        "https://api.coincap.io/v2/assets/bitcoin",
        "BcoinValue",
        "BcoinQt",
        "BitcoinP24Hr",
    ],
    [
        "ethereum",
        "ethereumN",
        "https://api.coincap.io/v2/assets/ethereum",
        "ethereumValue",
        "ethereumQt",
        "ethereumP24Hr",
    ],
    [
        "bitcoin-cash",
        "bitcoin-cashN",
        "https://api.coincap.io/v2/assets/bitcoin-cash",
        "bitcoin-cashValue",
        "bitcoin-cashQt",
        "bitcoin-cashP24Hr",
    ],
    [
        "stellar",
        "stellarN",
        "https://api.coincap.io/v2/assets/stellar",
        "stellarValue",
        "stellarQt",
        "stellarP24Hr",
    ],
    [
        "litecoin",
        "litecoinN",
        "https://api.coincap.io/v2/assets/litecoin",
        "litecoinValue",
        "litecoinQt",
        "litecoinP24Hr",
    ],
    [
        "cardano",
        "cardanoN",
        "https://api.coincap.io/v2/assets/cardano",
        "cardanoValue",
        "cardanoQt",
        "cardanoP24Hr",
    ],
    [
        "tron",
        "tronN",
        "https://api.coincap.io/v2/assets/tron",
        "tronValue",
        "tronQt",
        "tronP24Hr",
    ],
    [
        "monero",
        "moneroN",
        "https://api.coincap.io/v2/assets/monero",
        "moneroValue",
        "moneroQt",
        "moneroP24Hr",
    ],
    [
        "dogecoin",
        "dogecoinN",
        "https://api.coincap.io/v2/assets/dogecoin",
        "dogecoinValue",
        "dogecoinQt",
        "dogecoinP24Hr",
    ],
    [
        "xrp",
        "xrpN",
        "https://api.coincap.io/v2/assets/xrp",
        "xrpValue",
        "xrpQt",
        "xrpP24Hr",
    ],
    [
        "polkadot",
        "polkadotN",
        "https://api.coincap.io/v2/assets/polkadot",
        "polkadotValue",
        "polkadotQt",
        "polkadotP24Hr",
    ],
    [
        "usd-coin",
        "usd-coinN",
        "https://api.coincap.io/v2/assets/usd-coin",
        "usd-coinValue",
        "usd-coinQt",
        "usd-coinP24Hr",
    ],
    [
        "uniswap",
        "uniswapN",
        "https://api.coincap.io/v2/assets/uniswap",
        "uniswapValue",
        "uniswapQt",
        "uniswapP24Hr",
    ],
    [
        "eos",
        "eosN",
        "https://api.coincap.io/v2/assets/eos",
        "eosValue",
        "eosQt",
        "eosP24Hr",
    ],
    [
        "tether",
        "tetherN",
        "https://api.coincap.io/v2/assets/tether",
        "tetherValue",
        "tetherQt",
        "tetherP24Hr",
    ],
    [
        "neo",
        "neoN",
        "https://api.coincap.io/v2/assets/neo",
        "neoValue",
        "neoQt",
        "neoP24Hr",
    ],
    [
        "dash",
        "dashN",
        "https://api.coincap.io/v2/assets/dash",
        "dashValue",
        "dashQt",
        "dashP24Hr",
    ],
    [
        "binance-coin",
        "binance-coinN",
        "https://api.coincap.io/v2/assets/binance-coin",
        "binance-coinValue",
        "binance-coinQt",
        "binance-coinP24Hr",
    ],
    [
        "tezos",
        "tezosN",
        "https://api.coincap.io/v2/assets/tezos",
        "tezosValue",
        "tezosQt",
        "tezosP24Hr",
    ],
    [
        "zcash",
        "zcashN",
        "https://api.coincap.io/v2/assets/zcash",
        "zcashValue",
        "zcashQt",
        "zcashP24Hr",
    ],
    [
        "filecoin",
        "filecoinN",
        "https://api.coincap.io/v2/assets/filecoin",
        "filecoinValue",
        "filecoinQt",
        "filecoinP24Hr",
    ],
    [
        "vechain",
        "vechainN",
        "https://api.coincap.io/v2/assets/vechain",
        "vechainValue",
        "vechainQt",
        "vechainP24Hr",
    ],
];

var nameCripto;
var value;
var available;
var variation24h;
var parsedVal;
var parsedQt;
var parsedVariation;
var inserirPopUpNameTag;
var rawNameCripto;

var datatable;
var dataSet = [];

async function getAPICoin(coin) {
    let response = await fetch(coin[2]);
    let data = await response.json();
    nameCripto = data.data.name;
    rawNameCripto = coin[0];
    value = data.data.priceUsd;
    available = data.data.supply;
    variation24h = data.data.changePercent24Hr;
    parsedVal = parseFloat(value).toFixed(4);
    parsedQt = parseFloat(available).toFixed(0);
    parsedVariation = parseFloat(variation24h).toFixed(1);
    if (document.getElementById(coin[1])) {
        document.getElementById(coin[1]).textContent = nameCripto;
    }
    if (document.getElementById(coin[3])) {
        document.getElementById(coin[3]).textContent = parsedVal;
    }
    if (document.getElementById(coin[4])) {
        document.getElementById(coin[4]).textContent = parsedQt;
    }
    if (document.getElementById(coin[5])) {
        document.getElementById(coin[5]).textContent = parsedVariation;
    }

    if (document.getElementById("datatable_fixed_header")) {
        createTable();
    }
}


for (let i = 0; i < coins.length; i++) {
    let coin = coins[i];
    getAPICoin(coin);
    setInterval(function() {
        getAPICoin(coin);
    }, 5000);
}


//***********************DataTable******************************

if (document.getElementById("datatable_fixed_header")) {
    table_inicialize();
    setTimeout(function() {
        createTable();
    }, 1000);
}

function table_inicialize() {
    datatable = $("#datatable_fixed_header").DataTable({
        data: dataSet,
        columns: [
            { title: "" },
            { title: "Moeda" },
            { title: "Preço" },
            { title: "Alteração 24 H" },
            { title: "Registar" },
            { title: "Favoritos" },
        ],
    });

    $("#datatable_fixed_header tbody").on("click", "td", function() {
        inserirPopUpNameTag = datatable.cell(this, 1).node().firstChild.firstChild;
        console.log(inserirPopUpNameTag);
        // cell.data(cell.data() + 1).draw();

        // datatable
        //     .row( this )
        //     .data( cell )
        //     .draw();
        // note - call draw() to update the table's draw state with the new data
    });
}

let count = 0;

function createTable() {
    if (count < coins.length) {
        //create table
        let obj = [];
        obj.push(
            '<div class= "cryptoTableImagem"><img src = "./icons/cripto.png"></img></div>'
        );
        obj.push("<span>" + nameCripto + "</span>");
        obj.push("<span>" + parsedVal + " $" + "</span>");
        obj.push("<span>" + parsedVariation + " %" + "</span>");

        obj.push(
            "<div class='cryptoTableRegistar'><a href='../../production/insertPopup.php?coinName=" + "\"" + rawNameCripto + "\"" + "&userId=" + 1 + "'><button type='button' class='btn btn-success '>Registar Investimento</button></a></div>"
        );
        obj.push(
            '<div class="cryptoTableFavoritos"><img src="icons/Favorite-512.png" alt="Imagem estrela favorito"></div>'
        );

        datatable.row.add(obj).draw().node();



        count++;
    } else {
        updateTable();
    }
}

function updateTable() {
    //Update price of cripto
    let row = 0;
    datatable.rows().every(function() {
        if (this.data()[1] == "<span>" + nameCripto + "</span>") {
            // console.log("data: " + this.data()[1] + ", name: " + nameCripto);
            datatable
                .cell(row, 2)
                .data(parsedVal + " $")
                .draw();
        }
        row++;
    });
}
