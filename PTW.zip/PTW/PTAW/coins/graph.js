var requestOptions = {
    method: 'GET',
    redirect: 'follow'
};



var period = 90;
var currency = 'usd';
var coin = 'bitcoin';

async function drawGraph(requestOptions, period, coin) {
    let response = await fetch("https://api.coincap.io/v2/assets/" + coin + "/history?interval=d1", requestOptions);
    let myData = await response.json();
    // let data = new Array(myData.data.length);
    let endIndex = myData.data.length - 1;
    let data = new Array(period);
    for (let i = 0; i < period; i++) {
        data[i] = { year: myData.data[endIndex - i]['time'], value: myData.data[endIndex - i]['priceUsd'] };
    }
    if ($('#graph_line').length) {

        Morris.Line({
            element: 'graph_line',
            xkey: 'year',
            ykeys: ['value'],
            labels: ['Value'],
            hideHover: 'auto',
            lineColors: ['#26B99A', '#34495E', '#ACADAC', '#3498DB'],
            data,
            resize: true
        });

        $MENU_TOGGLE.on('click', function() {
            $(window).resize();
        });

    }
}

drawGraph(requestOptions, period, coin);
