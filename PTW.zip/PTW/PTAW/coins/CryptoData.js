var requestOptions = {
    method: 'GET',
    redirect: 'follow'
};


var period = 90;
var currency = 'usd';
var currentCoin = 'bitcoin';

async function drawGraph(requestOptions, period, currentCoin) {
    let response = await fetch("https://api.coincap.io/v2/assets/" + currentCoin + "/history?interval=d1", requestOptions);
    let myData = await response.json();
    let endIndex = myData.data.length - 1;
    let data = new Array(period);
    for (let i = 0; i < period; i++) {
        data[i] = { year: myData.data[endIndex - i]['time'], value: myData.data[endIndex - i]['priceUsd'] };
    }
    if (document.getElementById("coinValue")) {
        let tempValue = myData.data[endIndex]['priceUsd'];
        document.getElementById("coinValue").textContent = parseFloat(tempValue).toFixed(12) + "$";
    }
    if ($('#graph_line').length) {
        $('#graph_line').empty(); // Clears graph before drawing
        Morris.Line({
            element: 'graph_line',
            xkey: 'year',
            ykeys: ['value'],
            labels: ['Value'],
            hideHover: 'auto',
            lineColors: ['#26B99A', '#34495E', '#ACADAC', '#3498DB'],
            data,
            resize: true
        });

        $MENU_TOGGLE.on('click', function() {
            $(window).resize();
        });

    }
}


async function updateGraph(newPeriod) {
    period = newPeriod;
    drawGraph(requestOptions, period, currentCoin);
}

const coins = [
    [
        "bitcoin",
        "BcoinN",
        "https://api.coincap.io/v2/assets/bitcoin",
        "BcoinValue",
        "BcoinQt",
        "BitcoinP24Hr",
    ],
    [
        "ethereum",
        "ethereumN",
        "https://api.coincap.io/v2/assets/ethereum",
        "ethereumValue",
        "ethereumQt",
        "ethereumP24Hr",
    ],
    [
        "bitcoin-cash",
        "bitcoin-cashN",
        "https://api.coincap.io/v2/assets/bitcoin-cash",
        "bitcoin-cashValue",
        "bitcoin-cashQt",
        "bitcoin-cashP24Hr",
    ],
    [
        "stellar",
        "stellarN",
        "https://api.coincap.io/v2/assets/stellar",
        "stellarValue",
        "stellarQt",
        "stellarP24Hr",
    ],
    [
        "litecoin",
        "litecoinN",
        "https://api.coincap.io/v2/assets/litecoin",
        "litecoinValue",
        "litecoinQt",
        "litecoinP24Hr",
    ],
    [
        "cardano",
        "cardanoN",
        "https://api.coincap.io/v2/assets/cardano",
        "cardanoValue",
        "cardanoQt",
        "cardanoP24Hr",
    ],
    [
        "tron",
        "tronN",
        "https://api.coincap.io/v2/assets/tron",
        "tronValue",
        "tronQt",
        "tronP24Hr",
    ],
    [
        "monero",
        "moneroN",
        "https://api.coincap.io/v2/assets/monero",
        "moneroValue",
        "moneroQt",
        "moneroP24Hr",
    ],
    [
        "dogecoin",
        "dogecoinN",
        "https://api.coincap.io/v2/assets/dogecoin",
        "dogecoinValue",
        "dogecoinQt",
        "dogecoinP24Hr",
    ],
    [
        "xrp",
        "xrpN",
        "https://api.coincap.io/v2/assets/xrp",
        "xrpValue",
        "xrpQt",
        "xrpP24Hr",
    ],
    [
        "polkadot",
        "polkadotN",
        "https://api.coincap.io/v2/assets/polkadot",
        "polkadotValue",
        "polkadotQt",
        "polkadotP24Hr",
    ],
    [
        "usd-coin",
        "usd-coinN",
        "https://api.coincap.io/v2/assets/usd-coin",
        "usd-coinValue",
        "usd-coinQt",
        "usd-coinP24Hr",
    ],
    [
        "uniswap",
        "uniswapN",
        "https://api.coincap.io/v2/assets/uniswap",
        "uniswapValue",
        "uniswapQt",
        "uniswapP24Hr",
    ],
    [
        "eos",
        "eosN",
        "https://api.coincap.io/v2/assets/eos",
        "eosValue",
        "eosQt",
        "eosP24Hr",
    ],
    [
        "tether",
        "tetherN",
        "https://api.coincap.io/v2/assets/tether",
        "tetherValue",
        "tetherQt",
        "tetherP24Hr",
    ],
    [
        "neo",
        "neoN",
        "https://api.coincap.io/v2/assets/neo",
        "neoValue",
        "neoQt",
        "neoP24Hr",
    ],
    [
        "dash",
        "dashN",
        "https://api.coincap.io/v2/assets/dash",
        "dashValue",
        "dashQt",
        "dashP24Hr",
    ],
    [
        "binance-coin",
        "binance-coinN",
        "https://api.coincap.io/v2/assets/binance-coin",
        "binance-coinValue",
        "binance-coinQt",
        "binance-coinP24Hr",
    ],
    [
        "tezos",
        "tezosN",
        "https://api.coincap.io/v2/assets/tezos",
        "tezosValue",
        "tezosQt",
        "tezosP24Hr",
    ],
    [
        "zcash",
        "zcashN",
        "https://api.coincap.io/v2/assets/zcash",
        "zcashValue",
        "zcashQt",
        "zcashP24Hr",
    ],
    [
        "filecoin",
        "filecoinN",
        "https://api.coincap.io/v2/assets/filecoin",
        "filecoinValue",
        "filecoinQt",
        "filecoinP24Hr",
    ],
    [
        "vechain",
        "vechainN",
        "https://api.coincap.io/v2/assets/vechain",
        "vechainValue",
        "vechainQt",
        "vechainP24Hr",
    ],
];

var nameCripto;
var value;
var available;
var variation24h;
var parsedVal;
var parsedQt;
var parsedVariation;
var inserirPopUpNameTag;
var rawNameCripto;

var datatable;
var dataSet = [];

let count = 0;

async function getAPICoin(coin) {
    let response = await fetch(coin[2]);
    let data = await response.json();
    nameCripto = data.data.name;
    rawNameCripto = coin[0];
    value = data.data.priceUsd;
    available = data.data.supply;
    variation24h = data.data.changePercent24Hr;
    parsedVal = parseFloat(value).toFixed(9);
    parsedQt = parseFloat(available).toFixed(0);
    parsedVariation = parseFloat(variation24h).toFixed(1);
    if (document.getElementById(coin[1])) {
        document.getElementById(coin[1]).textContent = nameCripto;
    }
    if (document.getElementById(coin[3])) {
        document.getElementById(coin[3]).textContent = parsedVal;
    }
    if (document.getElementById(coin[4])) {
        document.getElementById(coin[4]).textContent = parsedQt;
    }
    if (document.getElementById(coin[5])) {
        document.getElementById(coin[5]).textContent = parsedVariation;
    }

    if (document.getElementById("datatable_fixed_header")) {
        if (count < coins.length) {
            createTable();
        } else {
            //Update Price of Cripto
            datatable.cell("#" + rawNameCripto, 2).data(parsedVal + "$").draw()
        }
    }
}

//***********************DataTable******************************


function table_inicialize() {
    datatable = $("#datatable_fixed_header").DataTable({
        data: dataSet,
        columns: [
            { title: "" },
            { title: "Moeda" },
            { title: "Preço" },
            { title: "Alteração 24 H" },
            { title: "Registar" },

        ]
    });

    $("#datatable_fixed_header tbody").on("click", "td", function() {
        // inserirPopUpNameTag = datatable.cell(this, 1).node().firstChild.firstChild;
        // let newName = inserirPopUpNameTag.nodeValue.toLowerCase();
        // drawGraph(requestOptions, period, newName.replace(/ /g, "-")); // dirty hack to make sure graph switches with coin name instead of preferencial id
        // cell.data(cell.data() + 1).draw();
        // var id = datatable.row(this).id();
        // console.log(id);
        // if (document.getElementById("coinHeader")) {
        //     document.getElementById("coinHeader").textContent = inserirPopUpNameTag.nodeValue;
        // }

        // datatable
        //     .row( this )
        //     .data( cell )
        //     .draw();
        // note - call draw() to update the table's draw state with the new data
    });

    datatable.on('click', 'tr', function() {
        var id = this.id;
        var data = datatable.row(this).data();
        currentCoin = id;
        drawGraph(requestOptions, period, id);
        // alert('Clicked row id: ' + id);
        inserirPopUpNameTag = datatable.cell(this, 1).node().firstChild.firstChild;
        if (document.getElementById("coinHeader")) {
            document.getElementById("coinHeader").textContent = inserirPopUpNameTag.nodeValue;
        }
    });

}

function createTable() {
    //create table
    let obj = [];
    obj.push(
        '<div class= "cryptoTableImagem"><img src = "./icons/cripto.png"></img></div>'
    );
    obj.push("<span>" + nameCripto + "</span>");
    obj.push("<span>" + parsedVal + " $" + "</span>");

    if (parsedVariation > 0)
        obj.push('<span style="color: green; ">' + parsedVariation + " %" + "</span>");
    else if (parsedVariation < 0)
        obj.push('<span style="color: red; ">' + parsedVariation + " %" + "</span>");
    else
        obj.push("<span>" + parsedVariation + " %" + "</span>");


    obj.push(
        "<div class='cryptoTableRegistar'><a href='./insertPopup.php?coinName=" + rawNameCripto + "'><button type='button' class='btn btn-success '>Registar Investimento</button></a></div>"
    );

    obj.push(rawNameCripto);
    datatable.row.add(obj).node().id = rawNameCripto;

    datatable.draw(false);

    count++;
}

function mostraID() {

}

//***********************Run Time******************************

for (let i = 0; i < coins.length; i++) {
    let coin = coins[i];
    getAPICoin(coin);
    setInterval(function() {
        getAPICoin(coin);
    }, 5000);
}

if (document.getElementById("datatable_fixed_header")) {
    table_inicialize();
    setTimeout(function() {
        createTable();
    }, 1000);
}

if ($('#graph_line')) { // only run function if element is present in php
    drawGraph(requestOptions, period, currentCoin);
    if (document.getElementById("coinHeader")) {
        document.getElementById("coinHeader").textContent = "Bitcoin";
    }

}