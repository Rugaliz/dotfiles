// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})();

//Definição de características dos items do carrousel
var pads = document.getElementsByClassName("pad15");
if (pads.length==0){
  document.getElementsByClassName('x_panel')[0].style.display = "none";
}
for (var i = 0; i < pads.length; i++) {
  //Ao iniciar a página, seleciona o primeiro elemento e apresenta informação sobre o mesmo
  if (i == 0) {
    pads[i].style.backgroundColor = "#489FDF"; pads[i].style.color = "white"; pads[i].name = "selected"; pads[i].style.borderBottom = "2px solid #63666A";
    apresentaInfo(pads[i]);
  }
  //Mouseover no item do carroussel
  pads[i].addEventListener(
    "mouseover", function () {
      this.style.backgroundColor = "#489FDF";
      this.style.color = "white";
    }
  );
  //Mouseout no item do carroussel
  pads[i].addEventListener(
    "mouseout", function () {
      if (this.name != "selected") {
        this.style.backgroundColor = "";
        this.style.color = "#63666A";
      }
    }
  );
  //Mouse click no item do carroussel
  //Coloca todos os items do carrousel com as características normais, 
  //à exceção do selecionado
  pads[i].addEventListener(
    "click", function () {
      for (i = 0; i < document.getElementsByClassName("pad15").length; i++) {
        document.getElementsByClassName("pad15")[i].style.backgroundColor = ""; document.getElementsByClassName("pad15")[i].style.color = "#63666A";
        document.getElementsByClassName("pad15")[i].name = ""; document.getElementsByClassName("pad15")[i].style.borderBottom = "";
      }
      this.style.backgroundColor = "#489FDF"; this.style.color = "white"; this.name = "selected"; this.style.borderBottom = "2px solid #63666A";
      apresentaInfo(this);
    }
  );
}

function apresentaInfo(element) {
  //Definição de variáveis relativas a elementos existentes
  var info = element.querySelectorAll("p");
  var context = document.getElementsByClassName("x_content")[0];
  context.innerHTML = "";
  //Definição do título com o ID do depósito
  document.getElementById("deposit_title").innerHTML = info[0].innerHTML;

  //Criação e atribuição de valores ao gráfico e título (valor atual do investimento)
  var box = document.createElement("div");
  box.className = "icon-box"; box.style.maxWidth = "500px"; box.style.margin = "auto";

  var graph = document.createElement("canvas");
  graph.id = "depositsDoughnut";

  var title = document.createElement("div");
  title.style.textAlign = "center";

  var value = document.createElement("h3");
  value.innerHTML = info[3].innerHTML;

  title.appendChild(value); box.appendChild(graph); context.appendChild(box); context.appendChild(title); createGraph(info);

  //Criação e atribuição de valores à tabela (Detalhes sobre o depósito)
  var table = document.createElement("table");
  table.id = "datatable-fixed-header"; table.className = "table table-striped table-bordered"; table.style.width = "100%"; table.style.textAlign = "center";

  var body = document.createElement("tbody");
  var header_line = document.createElement("tr");
  var info_line = document.createElement("tr");

  var h1 = document.createElement("th");
  var h2 = document.createElement("th");
  var h3 = document.createElement("th");
  var h4 = document.createElement("th");
  var h5 = document.createElement("th");

  h1.style.width = "20%";
  h2.style.width = "20%";
  h3.style.width = "20%";
  h4.style.width = "20%";
  h5.style.width = "20%";

  h1.innerHTML = "Valor do investimento";
  h2.innerHTML = "Período de taxação";
  h3.innerHTML = "Valor da taxa";
  h4.innerHTML = "Prazo do depósito";
  h5.innerHTML = "Data de término";

  header_line.appendChild(h1);
  header_line.appendChild(h2);
  header_line.appendChild(h3);
  header_line.appendChild(h4);
  header_line.appendChild(h5);

  var v1 = document.createElement("td");
  var v2 = document.createElement("td");
  var v3 = document.createElement("td");
  var v4 = document.createElement("td");
  var v5 = document.createElement("td");

  v1.style.width = "20%";
  v2.style.width = "20%";
  v3.style.width = "20%";
  v4.style.width = "20%";
  v5.style.width = "20%";

  var inicial = info[1].innerHTML.split(":")[1].split("$")[0].split(">")[1].trim();
  inicial = inicial.replace(",", "");
  v1.innerHTML = parseFloat(inicial).toFixed(2) + " $";

  v2.innerHTML = info[2].innerHTML.split("|")[1].trim();

  v3.innerHTML = info[2].innerHTML.split("|")[0].split(":")[1].trim();

  v4.innerHTML = info[4].innerHTML + " anos";

  v5.innerHTML = info[5].innerHTML;

  info_line.appendChild(v1);
  info_line.appendChild(v2);
  info_line.appendChild(v3);
  info_line.appendChild(v4);
  info_line.appendChild(v5);

  body.appendChild(header_line);
  body.appendChild(info_line);
  table.appendChild(body);
  context.appendChild(table);

}

function createGraph(element) {
  //From inside the clicked element, colects the inner HTML from the used paragraphs and split them to get only the inicial value of the investment
  var inicial = element[1].innerHTML.split(":")[1].split("$")[0].split(">")[1].trim();
  //Replace the commas for nothing, making possible for the js to use it as float
  inicial = inicial.replace(",", "");
  //From inside the clicked element, colects the inner HTML from the used paragraphs and split them to get only the inicial value of the investment
  var atual = element[3].innerHTML.split(":")[1].split("$")[0].split(">")[1].trim();
  //Replace the commas for nothing, making possible for the js to use it as float
  atual = atual.replace(",", "");
  //Refreshes the graph with the info of the selected investment
  var ctx = document.getElementById("depositsDoughnut");
  var data = {
    labels: [
      "Valor investido ($)",
      "Lucro atual ($)"
    ],
    datasets: [{
      data: [parseFloat(inicial), parseFloat(atual - inicial).toFixed(2)],
      backgroundColor: [
        "#63666A",
        "#3498DB"
      ],
      hoverBackgroundColor: [
        "#63666A",
        "#49A9EA"
      ]

    }]
  };
  var canvasDoughnut = new Chart(ctx, {
    type: 'doughnut',
    tooltipFillColor: "rgba(51, 51, 51, 0.55)",
    data: data
  });
  //Apresenta o gráfico sem informação
  var ctx = document.getElementById("canvasDoughnut");
      var data = {
        labels: [
          "Valor investido ($)",
          "Lucro final ($)"
        ],
        datasets: [{
          data: ["","",""],
          backgroundColor: [
            "#63666A",
            "#489FDF"
          ],
          hoverBackgroundColor: [
            "#63666A",
            "#489FDF"
          ]

        }]
      };
  var canvasDoughnut = new Chart(ctx, {
    type: 'doughnut',
    tooltipFillColor: "rgba(51, 51, 51, 0.55)",
    data: data
  });
}

document.getElementById("invest").addEventListener("input", function () { insertDepositGraph(); });
document.getElementById("juro").addEventListener("input", function () { insertDepositGraph(); });
document.getElementById("taxacao").addEventListener("change", function () { insertDepositGraph(); });
document.getElementById("prazo").addEventListener("change", function () { insertDepositGraph(); });

function insertDepositGraph() {
  var juro, taxacao, prazo, invest;
  if ((document.getElementById("juro").value != "" && document.getElementById("juro").value > 0.00 && document.getElementById("juro").value < 2.01) && document.getElementById("taxacao").value != "" && document.getElementById("prazo").value != "" && (document.getElementById("invest").value != "" && document.getElementById("invest").value > 0.00 )) {
    invest = document.getElementById("invest").value;
    juro = document.getElementById("juro").value;
    taxacao = document.getElementById("taxacao").value;
    prazo = document.getElementById("prazo").value;

    if (taxacao == "Semestral") {
      taxacao = 2;
    } else if (taxacao == "Trimestral") {
      taxacao = 4;
    } else { taxacao = 1; }

    if (juro > 2) {
    } else {
      var final = (parseFloat(invest) + (parseFloat(invest * (juro / 100))) * taxacao * prazo).toFixed(2);
      var ctx = document.getElementById("canvasDoughnut");
      var data = {
        labels: [
          "Valor investido ($)",
          "Lucro final ($)"
        ],
        datasets: [{
          data: [parseFloat(invest), parseFloat(final - invest).toFixed(2)],
          backgroundColor: [
            "#63666A",
            "#489FDF"
          ],
          hoverBackgroundColor: [
            "#63666A",
            "#489FDF"
          ]

        }]
      };
      var canvasDoughnut = new Chart(ctx, {
        type: 'doughnut',
        tooltipFillColor: "rgba(51, 51, 51, 0.55)",
        data: data
      });
    }
  }
}
