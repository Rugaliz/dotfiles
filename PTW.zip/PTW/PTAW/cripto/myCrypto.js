var requestOptions = {
  method: "GET",
  redirect: "follow",
};

// var period = 90;
// var currency = "usd";
var currentCoin = null;
var datatableMyCrypto;
var dataToShowInGraph = new Array();

async function drawGraph(requestOptions, currentCoin) {
  let xhr = new XMLHttpRequest();

  if (currentCoin == null) {
    xhr.open("POST", "./php/cripto/recolherGraficoMinhaMoeda.php", true);
    xhr.send();
  } else {
    xhr.open(
      "GET",
      "./php/cripto/recolherGraficoMoedaIndividual.php?moeda_id=" + currentCoin,
      true
    );
    let stringEnviar = "moeda_id=" + currentCoin;
    // console.log(stringEnviar);
    xhr.send();
  }
  xhr.onload = function () {
    // if(currentCoin != null) document.write(xhr.response);
    var jsonToShowInGraph = JSON.parse(xhr.response);
    // console.log(jsonToShowInGraph);
    var today = new Date();
    dataToShowInGraph = new Array();
    var dataMaisAntigaDate = new Date(today);
    // console.log(jsonToShowInGraph.data);
    for (var i = 0; i < Object.keys(jsonToShowInGraph.data).length; i++) {
      var tempString = jsonToShowInGraph.data[i].data;
      var dataTemp = new Date(tempString);
      if (dataTemp < dataMaisAntigaDate) {
        // if (jsonToShowInGraph.data[i].tipo == "compra")
          dataMaisAntigaDate = dataTemp;
      }
    }

    var diasParaMostrarNoGraph = [];
    for (
      var d = new Date(dataMaisAntigaDate);
      d <= today;
      d.setDate(d.getDate() + 1)
    ) {
      diasParaMostrarNoGraph.push(new Date(d));
    }

    var counterUnico = 0;
    var valorTotal = 0;
    diasParaMostrarNoGraph.forEach((element) => {
      valorTotal = 0;
      for (var i = 0; i < Object.keys(jsonToShowInGraph.data).length; i++) {
        var tempString = jsonToShowInGraph.data[i].data;
        var dataTemp = new Date(tempString);

        if (element >= dataTemp) {
          if (jsonToShowInGraph.data[i].tipo == "compra") {
            valorTotal =
              parseFloat(valorTotal) +
              parseFloat(jsonToShowInGraph.data[i].moeda_quantidade);
          } else {
            valorTotal =
              parseFloat(valorTotal) -
              parseFloat(jsonToShowInGraph.data[i].moeda_quantidade);
          }
        }
      }

      // for (var i = 0; i < Object.keys(jsonToShowInGraph2.data).length; i++) {
      //   var tempString = jsonToShowInGraph2.data[i].data;
      //   var dataTemp = new Date(tempString);

      //   if (element > dataTemp) {
      //     valorTotal =
      //       parseFloat(valorTotal) +
      //       parseFloat(jsonToShowInGraph2.data[i].moeda_quantidade);
      //   }
      // }

      // console.log(valorTotal);
      dataToShowInGraph[counterUnico] = {
        year: element.getTime(),
        value: valorTotal,
      };
      counterUnico++;
      // console.log(i + "::::" + element);
    });
    // console.log(diasParaMostrarNoGraph);
    // console.log(dataToShowInGraph);
    document.getElementById("coinValue").textContent = valorTotal;
    $("#graph_line").empty(); // Clears graph before drawing
    Morris.Line({
      element: "graph_line",
      data: dataToShowInGraph,
      xkey: "year",
      ykeys: ["value"],
      labels: ["Value"],
      hideHover: "auto",
      lineColors: ["#26B99A", "#34495E", "#ACADAC", "#3498DB"],
      resize: true,
    });

    $MENU_TOGGLE.on("click", function () {
      $(window).resize();
    });
  };
}

async function fetchCoinPrice(elementoLinkTabela, requestOptions) {
  let response = await fetch(elementoLinkTabela, requestOptions);
  let respostaJson = await response.json();
  let respostaParsedValue = parseFloat(respostaJson.data.priceUsd).toFixed(9);
  return respostaParsedValue;
}

async function fetchCoinName(elementoLinkTabela, requestOptions) {
  let response = await fetch(elementoLinkTabela, requestOptions);
  let respostaJson = await response.json();
  return respostaJson.data.name;
}

// fetchCoinPrice("https://api.coincap.io/v2/assets/ethereum");

if ($("#graph_line")) {
  drawGraph(requestOptions, currentCoin);
}

var valorApresentarTabela1 = 0;

datatableMyCrypto = $("#moedas-datatable").DataTable({
  ajax: "./php/cripto/recolherMinhasMoedas.php",
  columns: [
    { data: "moeda_nome" },
    { data: "dinheiro_investido" },
    { data: "moeda_quantidade" },
    { data: "api_associada" },
    {
      data: "moeda_id",
    },
    {
      data: "dinheiro_ganho",
    },
    {
      data: null,
    },
    {
      data: null,
    },
  ],
  columnDefs: [
    {
      targets: -2,
      data: null,
      defaultContent:
        "<button id='vender' type='button' class='btn btn-success '>Vender</button>",
    },
    {
      targets: -1,
      data: null,
      defaultContent:
        "<button id='comprar' type='button' class='btn btn-success '>Comprar</button>",
    },
  ],
  initComplete: function (settings, json) {
    document.getElementsByClassName("tabela_my_crypto")[0].textContent =
      datatableMyCrypto.column(1).data().sum() + "$";
    document.getElementsByClassName(
      "tabela_my_crypto"
    )[2].textContent = datatableMyCrypto.column(2).data().sum();
    // console.log(settings.api_associada);
    datatableMyCrypto
      .column(3)
      .data()
      .each(async function (value, index) {
        // console.log( 'Data in index: '+index+' is: '+value );
        let valorAtualMoeda = await fetchCoinPrice(value);
        var nomeAtualMoeda = await fetchCoinName(value);
        // console.log(nomeAtualMoeda);
        // console.log(valorAtualMoeda);
        var valorAtualMoedaCarteira =
          parseFloat(valorAtualMoeda) *
          datatableMyCrypto.column(2).row(index).data()[0];
        datatableMyCrypto
          .cell({ row: index, column: 3 })
          .data(valorAtualMoedaCarteira + "$");

        datatableMyCrypto.column(3).cells().invalidate().render();
        // console.log(valorAtualMoeda);
        // console.log(datatableMyCrypto.cell({row:index, column:1}).data());
        datatableMyCrypto
          .cell({ row: index, column: 4 })
          .data(
            datatableMyCrypto.cell({ row: index, column: 5 }).data() -
              datatableMyCrypto.cell({ row: index, column: 1 }).data() +
              "$"
          );

        valorApresentarTabela1 =
          parseFloat(valorApresentarTabela1) +
          parseFloat(valorAtualMoedaCarteira);
        document.getElementsByClassName("tabela_my_crypto")[1].textContent =
          valorApresentarTabela1 + "$";

        document.getElementsByClassName("tabela_my_crypto")[3].textContent =
          valorApresentarTabela1 -
          parseFloat(datatableMyCrypto.column(1).data().sum()) +
          "$";

        if (
          valorAtualMoedaCarteira >
          datatableMyCrypto.cell({ row: index, column: 1 }).data()
        ) {
          // datatableMyCrypto.cell({ row: index, column: 3 }).addClass("teste");
          console.log("imensos testes");
        }

        datatableMyCrypto
          .cell({ row: index, column: 1 })
          .data(datatableMyCrypto.cell({ row: index, column: 1 }).data() + "$");
        datatableMyCrypto
          .cell({ row: index, column: 5 })
          .data(datatableMyCrypto.cell({ row: index, column: 5 }).data() + "$");
        datatableMyCrypto
          .cell({ row: index, column: 0 })
          .data(nomeAtualMoeda);
      });
    document.getElementById(
      "coinValue"
    ).textContent = document.getElementsByClassName(
      "tabela_my_crypto"
    )[2].textContent;
  },
});

datatableMyCrypto.on("click", "#vender", function () {
  var data = datatableMyCrypto.row($(this).parents("tr")).data();
  window.location.href =
    "./sellPopup.php?coinId=" + data[4] + "&maxMoeda=" + data[0] + "&nomeMoeda=" + data[2];
});

datatableMyCrypto.on("click", "#comprar", function () {
  var data = datatableMyCrypto.row($(this).parents("tr")).data();
  window.location.href =
    "./insertPopup.php?coinName=" + data[2];
});

datatableMyCrypto.on("click", "td", function () {
  // var data = datatableMyCrypto.row( $(this).parents('tr') ).data();
  // alert( data[0] +"'s salary is: "+ data[ 4 ] );
  document.getElementById("coinHeader").textContent = datatableMyCrypto
  .row($(this).parents("tr")).node().firstChild.textContent;
  drawGraph(
    requestOptions,
    datatableMyCrypto.row($(this).parents("tr")).data()[4]
  );
});

datatableMyCrypto.on('click', 'tr', function() {
  
});

jQuery.fn.dataTable.Api.register("sum()", function () {
  return this.flatten().reduce(function (a, b) {
    if (typeof a === "string") {
      a = a.replace(/[^\d.-]/g, "") * 1;
    }
    if (typeof b === "string") {
      b = b.replace(/[^\d.-]/g, "") * 1;
    }

    return a + b;
  }, 0);
});
