// console.log(sessionIdUtilizador);
// console.log(sessionNameCoin);


(function () {
   'use strict'

   // Fetch all the forms we want to apply custom Bootstrap validation styles to
   var forms = document.querySelectorAll('.needs-validation')

   // Loop over them and prevent submission
   Array.prototype.slice.call(forms)
      .forEach(function (form) {
         form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
               event.preventDefault()
               event.stopPropagation()
            }

            form.classList.add('was-validated')
         }, false)
      })
})();

var quantidadeMoedaTexto = document.getElementById("quantidadeMoeda");
quantidadeMoedaTexto.addEventListener('input', function () {
   if (document.getElementById("precoMoeda").value != "") {
      document.getElementById("valorVenda").value = parseFloat(document.getElementById("quantidadeMoeda").value) * parseFloat(document.getElementById("precoMoeda").value);
   }
});

var precoMoedaTexto = document.getElementById("precoMoeda");
precoMoedaTexto.addEventListener('input', function () {
   if (document.getElementById("quantidadeMoeda").value != "") {
      document.getElementById("valorVenda").value = parseFloat(document.getElementById("quantidadeMoeda").value) * parseFloat(document.getElementById("precoMoeda").value);
   }
});

var valorTotalTexto = document.getElementById("valorVenda");
valorTotalTexto.addEventListener('input', function () {
   if (document.getElementById("precoMoeda").value != "") {
      document.getElementById("quantidadeMoeda").value = parseFloat(document.getElementById("valorVenda").value) / parseFloat(document.getElementById("precoMoeda").value);
   }
});
var today = new Date().toISOString().split('T')[0];
document.getElementById("data").setAttribute('max', today);
function inserirInvestimento() {
   var qtdMoeda = parseFloat(document.getElementById("quantidadeMoeda").value);
   var vlrInvestimento = parseFloat(document.getElementById("valorInvestimento").value);
   var prcMoeda = parseFloat(document.getElementById("precoMoeda").value);
   var data = document.getElementById("data").value;


   console.log(qtdMoeda);
   console.log(prcMoeda);

   console.log(vlrInvestimento);

   if (qtdMoeda != "" && vlrInvestimento != "" && prcMoeda != "") {
      console.log(qtdMoeda != "");
      console.log(vlrInvestimento != "");
      console.log(prcMoeda != "");
      window.alert("Por favor preencha todos os campos corretamente");
      return null;
   }

   var xhr = new XMLHttpRequest();
   xhr.open("GET", "./php/cripto/inserirInvestimento.php?qtd=" + qtdMoeda + "&vlr=" + vlrInvestimento + "&prc=" + prcMoeda + "&data=" + data + "&user=" + sessionIdUtilizador + "&coin=" + sessionNameCoin, true);

   xhr.onload = function () {
      console.log(xhr.response);
      window.alert("Inserção de movimento efetuado com sucesso!");
      window.location.replace("./cripto.php");
      document.write(xhr.response);
   };

   xhr.onerror = function () {
      console.log("ERRO na inserção");
   };

   xhr.onprogress = function () {
      console.log("a inserir");
   };

   xhr.send();
}
// document.getElementById("inserirInvestimento").addEventListener('click', function(){
//    inserirInvestimento();
// });