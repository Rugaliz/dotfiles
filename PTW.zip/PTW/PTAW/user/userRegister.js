let userName = document.getElementById("userName_register");
let userMail = document.getElementById("userMail_register");
let userBirth = document.getElementById("userBirth_register");
let userAddress = document.getElementById("userAdress_register");
let userPass = document.getElementById("userPass_register");
let userPassRepeat = document.getElementById("userPassRepeat_register");
let userTel = document.getElementById("userPhone_register");

var today = new Date().toISOString().split('T')[0];
document.getElementById("userBirth_register").setAttribute('max', today);

let xhr = new XMLHttpRequest();
xhr.responseType = 'json';

function registerUser() {
    console.log("aqui");
    xhr.onload = function () {
        if (xhr.status == 200) {
            if (xhr.response.erro !== "none") {
                window.alert(xhr.response.erro);
            } else {
                console.log(xhr.response);
            }
        }
    };
    xhr.open("GET", './php/user/register.php?name=' + userName.value + '&email=' + userMail.value + '&address=' + userAddress.value + "&birthday=" + userBirth.value + "&phone=" + userTel.value + "&pass=" + userPass.value + "&passRepeat=" + userPassRepeat.value, true);
    // 3. Send the request to the server
    xhr.send();
}

(function () {
    'use strict'
  
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')
  
    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
      .forEach(function (form) {
        form.addEventListener('submit', function (event) {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }
  
          form.classList.add('was-validated')
        }, false)
      })
  })();