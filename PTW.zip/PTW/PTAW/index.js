let quantia = document.getElementById("simquantia");
let ganho = document.getElementById("simganho");
let taxa = document.getElementById("simtaxa");
let periodo = document.getElementById("simperiodo");
let prazo = document.getElementById("simprazo");
let valorFinal;
let quantiaAtual = 0;
let ganhoAtual = 0;
let quantiaInicial;



var form = document.getElementById('sim');
form.addEventListener('change', function () {
  let per = periodo.value;
  let pra = prazo.value;
  let perNum;
  let praNum;

  if (quantia.value != "" && taxa.value != "") {
   
  
  if (per != "Periodo de taxação" && pra != "Prazo de investimento") {
    if (per == "Trimestre") {
      perNum = 4;

    } else if (per == "Semestral") {
      perNum = 2;
    }else if(per== "Anual"){
      perNum = 1;
    }

    if (pra == "3 anos") {
      praNum = 3;
    } else if (pra == "5 anos") {
      praNum = 5;
    } else if (pra == "10 anos") {
      praNum = 10;
    }else if(pra =="15 anos"){
      praNum = 15;  
    }else if(pra == "20 anos"){
      praNum = 20;
    }
    valorFinal = (quantia.value * (taxa.value / 100)) * (praNum * perNum);
    ganho.setAttribute ("value",valorFinal) ;
    quantiaAtual = quantia.value;
    ganhoAtual = ganho.value;
    console.log(ganhoAtual + " " + quantiaAtual);

    console.log(perNum + " " + praNum);
    
    if(ganho.value != ""){
      ganho.value = valorFinal;
    }
  }
}
  /*
  if(quantia.value != "" && taxa.value != ""){
    ganho.setAttribute("value",quantia.value * taxa.value);
  }else
    //console.log(quantia.value);
    ganho.setAttribute("value",taxa.value);*/
});

function alteraData() {
    if (ganhoAtual > 0) {
      let datas = [{ x: 'Investimento', y: quantiaAtual, z: parseFloat(quantiaAtual) + parseFloat(ganhoAtual) }]
      createGraph(datas);
    }
}


var data = [{ x: 'Investimento', y: 150, z: 100 }
]

function createGraph(data) {
  if ($('#graph_bar').length) {
      $('#graph_bar').empty();
    Morris.Bar({
      element: 'graph_bar',
      data,
      // data: [
      //     { device: 'iPhone 4', geekbench: 380 },
      //     { device: 'iPhone 4S', geekbench: 655 },
      //     { device: 'iPhone 3GS', geekbench: 275 },
      //     { device: 'iPhone 5', geekbench: 1571 },
      //     { device: 'iPhone 5S', geekbench: 655 },
      //     { device: 'iPhone 6', geekbench: 2154 },
      //     { device: 'iPhone 6 Plus', geekbench: 1144 },
      //     { device: 'iPhone 6S', geekbench: 2371 },
      //     { device: 'iPhone 6S Plus', geekbench: 1471 },
      //     { device: 'Other', geekbench: 1371 }
      // ],
      xkey: 'x',
      ykeys: ['y', 'z'],
      labels: ['Investido', 'Valorização'],
      barRatio: 0.4,
      barColors: ['#63666A', '#489FDF', '#BEC6C4', '#6AD1E3'],
      xLabelAngle: 35,
      hideHover: 'auto',
      resize: true
    });

  }
}



var requestOptions = {
  method: 'GET',
  redirect: 'follow'
};


async function getTopCoins(requestOptions) {
  let response = await fetch("https://api.coincap.io/v2/assets", requestOptions);
  let newInput = [];
  let topCoins = await response.json();
  for (let i = 0; i < 12; i++) {
    newInput = newInput + " <div > <img src=" + "icons/cripto.png" + "> <h6><span>" + topCoins.data[i].name + "</span></h6><h6>Valorização: <span>" + parseFloat(topCoins.data[i].priceUsd).toFixed(9) + "</span> $</h6> <h6>Quantidade disponível: <span>" + parseFloat(topCoins.data[i].supply).toFixed(0) + "</span></h6> <h6>Variação 24 H: <span>" + parseFloat(topCoins.data[i].changePercent24Hr).toFixed(1) + "</span> %</h6> </div>";
  }
  document.getElementById("TopCoins").innerHTML = newInput;

}


if (document.getElementById("TopCoins")) {
  getTopCoins();
  setInterval(function () {
    getTopCoins();
  }, 5000);

  setInterval(function () {
    alteraData();
  }, 1000);
}
  // createGraph(data);
