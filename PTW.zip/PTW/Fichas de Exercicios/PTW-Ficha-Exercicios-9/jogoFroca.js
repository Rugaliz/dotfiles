let grid = document.getElementsByClassName("grid")[0];
let word = document.getElementsByClassName("word")[0];
let forca = document.getElementsByClassName("forca")[0];

let words = ["AJAX", "CSS", "DOM", "HTML", "JAVASCRIPT", "JQUERY", "JSON", "PHP", "PROGRAMACAO", "TECNOLOGIAS", "WEB"];
let images = ["wrong-1.gif", "wrong-2.gif", "wrong-3.gif", "wrong-4.gif", "wrong-5.gif", "wrong-6.gif", "wrong-7.gif"];
let solution;
let erro = 0;
let correta = 0;

for (i = 65; i <= 90; i++) {
    let item = document.createElement("div");
    item.className = "itens";
    item.innerHTML = String.fromCharCode(i);
    item.addEventListener("click", function() { verification(this) });
    item.addEventListener("mouseover", function() { backgroundChange(this, "lightblue") });
    item.addEventListener("mouseout", function() { backgroundChange(this, "white") });
    grid.appendChild(item);
}

var x = Math.floor((Math.random() * 11));
solution = words[x];

for (i = 0; i < solution.length; i++) {
    let t = document.createElement("div");
    t.className = "letter";
    t.id = i;
    word.appendChild(t);
}

function verification(obj) {
    let verifica = false;

    if (erro < 7) {
        for (i in solution) {
            if (obj.innerHTML == solution[i]) {
                verifica = true;
                obj.style.fontWeight = "bold";
                obj.style.color = "red";
                let letra = document.getElementById(i);

                if (letra.innerHTML == "") {
                    correta++;
                    letra.innerHTML = solution[i];
                }

                if (correta == solution.length) {
                    setTimeout("window.alert('Parabens!'); location.reload()", 500);
                }
            }
        }

        if (verifica == false) {
            if (obj.getElementsByTagName('img').length == 0) {
                erro++;
                incorret = document.createElement("img");
                incorret.src = "imagens/incorrect.gif";
                incorret.className = "incorrect";
                obj.appendChild(incorret);
                img = document.createElement("img");
                img.src = "imagens/" + images[erro - 1];
                forca.appendChild(img);
            }

            // if (obj.style.background == '') {
            //     erro++;
            //     obj.style.background = "url(imagens/incorrect.gif)";
            //     obj.style.backgroundRepeat = "no-repeat"
            //     obj.style.backgroundPosition = "center";
            //     img = document.createElement("img");
            //     img.src = "imagens/" + images[erro - 1];
            //     forca.appendChild(img);
            // }
            if (erro == 7) {
                setTimeout("window.alert('Acabaram as tentativas!'); location.reload()", 500);
            }
        }
    }
}

function backgroundChange(obj, background) {
    obj.style.backgroundColor = background;
}