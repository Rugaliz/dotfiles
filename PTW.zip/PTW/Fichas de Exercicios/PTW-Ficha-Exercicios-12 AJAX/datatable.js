table = document.getElementById("table");
var ano;
table1 = document.getElementById("table1");

function firstResult() {
    let xhr = new XMLHttpRequest();
    xhr.responseType = 'json';
    table.innerHTML = "";
    table1.innerHTML = "";

    let title = document.createElement('tr');
    let th1 = document.createElement('th');
    th1.innerHTML = "Ano";
    title.appendChild(th1);
    let th2 = document.createElement('th');
    th2.innerHTML = "Mês";
    title.appendChild(th2);
    let th3 = document.createElement('th');
    th3.innerHTML = "Chave Móvel Digital";
    title.appendChild(th3);
    let th4 = document.createElement('th');
    th4.innerHTML = "Cartão de cidadão";
    title.appendChild(th4);
    let th5 = document.createElement('th');
    th5.innerHTML = "Advogado";
    title.appendChild(th5);
    let th6 = document.createElement('th');
    th6.innerHTML = "Solicitador";
    title.appendChild(th6);
    let th7 = document.createElement('th');
    th7.innerHTML = "Notário";
    title.appendChild(th7);

    table.appendChild(title);

    // 4. This function will be called after the response is received from the server
    xhr.onload = function() {
        if (xhr.status == 200) {
            xhr.response.forEach(element => {
                let tr = document.createElement('tr');

                for (let valor in element) {
                    let colum = document.createElement('td');
                    colum.innerHTML = element[valor];
                    tr.appendChild(colum);
                }

                table.appendChild(tr);
            });

        } else
            window.alert("Error" + xhr.status + ": " + xhr.statusText);
    };

    // 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
    xhr.open("GET", 'Autenticacoes-Evolucao-por-Certificado.json', true);
    // 3. Send the request to the server
    xhr.send();
}

// second Result


function secondResult() {
    table.innerHTML = "";
    table1.innerHTML = "";
    ano = 0;

    let title = document.createElement('tr');
    let th1 = document.createElement('th');
    th1.innerHTML = "Ano";
    title.appendChild(th1);
    let th2 = document.createElement('th');
    th2.innerHTML = "Número";
    title.appendChild(th2);
    table1.appendChild(title);

    let xhr = new XMLHttpRequest();
    xhr.responseType = 'json';

    // 4. This function will be called after the response is received from the server
    xhr.onload = function() {
        if (xhr.status == 200) {
            xhr.response.filter(verifica);

        } else
            window.alert("Error" + xhr.status + ": " + xhr.statusText);
    };

    // 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
    xhr.open("GET", 'Autenticacoes-Evolucao-por-Certificado.json', true);
    // 3. Send the request to the server
    xhr.send();
}

function verifica(anos) {
    if (anos.Ano == ano) {
        let a = document.getElementById(ano);
        let cout = a.innerHTML;
        a.innerHTML = parseInt(cout) + 1;
    } else {
        ano = anos.Ano;
        let tr = document.createElement('tr');
        let td1 = document.createElement('td');
        td1.innerHTML = ano;
        tr.appendChild(td1);

        let td2 = document.createElement('td');
        td2.id = ano;
        td2.innerHTML = 1;
        tr.appendChild(td2);

        table1.appendChild(tr);
    }
}