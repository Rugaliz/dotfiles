let objs = document.getElementsByClassName("itens");
let e = document.getElementById("expressao");
let r = document.getElementById("resultado");
let buttons = document.getElementsByClassName("buttons")[0];

apresentar();

function apresentar() {
    let textAlert = prompt("Intrudoza o numero de botões numéricos que pretende. Só é possivel de 10 a 50", "10");

    if (textAlert < 10 || textAlert > 49) {
        window.alert("Valor introduzido inválido!");
        apresentar();
    } else {
        let item;
        for (i = 0; i < textAlert; i++) {
            item = document.createElement("div");
            item.className = "itens";
            item.innerHTML = i;
            buttons.appendChild(item);
        }

        let operacoes = ["C", "=", "+", "-", "*", "/"];

        for (i in operacoes) {
            item = document.createElement("div");
            item.className = "itens";
            item.innerHTML = operacoes[i];
            buttons.appendChild(item);
        }
    }
}


for (i = 0; i < objs.length; i++) {
    let exp = objs[i].innerHTML;

    objs[i].addEventListener("click", function() { expressao(exp) });
    objs[i].addEventListener("mouseover", function() { backgroundChange(this, "gray") });
    objs[i].addEventListener("mouseout", function() { backgroundChange(this, "green") });
}

function backgroundChange(obj, background) {
    obj.style.backgroundColor = background;
}

function expressao(exp) {
    if (exp == 'C') {
        e.innerHTML = "";
        r.innerHTML = "";
    } else if (exp == '=') {
        if (e.textContent.length == 0)
            r.innerHTML = "expressão inválida";
        else {
            let resultado = eval(e.innerHTML);

            if (isFinite(resultado))
                r.innerHTML = resultado;
            else
                r.innerHTML = "expressão inválida";
        }
    } else {
        e.innerHTML = e.textContent + exp;
    }
}
