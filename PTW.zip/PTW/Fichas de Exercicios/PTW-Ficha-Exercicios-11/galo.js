let numTab = document.getElementById("numTab");
let player = document.getElementById("player");
let board = document.getElementById("board");
let message = document.getElementById("message");
let num;
let draw = 0;
// progressbar
var elem = document.getElementById("myBar");
var width = 100;
var id = setInterval(function() { frame(); }, 100);

create();

move();
numTab.addEventListener("change", function() { create() });

function create() {
    num = numTab.value;

    if (board.hasChildNodes) {
        while (board.firstChild) {
            board.removeChild(board.lastChild);
        }
    }

    let colums = "";

    for (i = 0; i < num; i++) {
        colums = colums + " " + "auto";
    }

    board.style.gridTemplateColumns = colums;

    for (i = 0; i < num * num; i++) {
        let item = document.createElement("div");
        item.className = "item";
        item.id = i;
        item.addEventListener("click", function() { add(this) });
        board.appendChild(item);
    }
}

function frame() {
    if (width <= 1) {
        clearInterval(id);
        if (player.innerHTML == "Jogador O")
            player.innerHTML = "Jogador X";
        else
            player.innerHTML = "Jogador O";

        clearFrame();
    } else {
        width--;
        elem.style.width = width + '%';
    }
}

function clearFrame() {
    window.clearInterval(id);
    width = 100;
    id = setInterval(function() { frame(); }, 100);
}

function add(obj) {
    clearFrame();
    if (player.innerHTML == "Jogador X" && obj.style.backgroundImage == '') {
        // let x = document.createElement("img");
        // x.src = "Imagens/cruz.jpg";
        // obj.appendChild(x);
        obj.style.backgroundImage = "url(Imagens/cruz.jpg)";
        obj.style.backgroundRepeat = "no-repeat"
        obj.style.backgroundPosition = "center";
        player.innerHTML = "Jogador O";

        draw++;

        setTimeout(function() {
            verifica(obj, "cruz");
        }, 50);

    } else if (player.innerHTML == "Jogador O" && obj.style.backgroundImage == '') {
        // let o = document.createElement("img");
        // o.src = "Imagens/bola.jpg";
        // obj.appendChild(o);
        obj.style.backgroundImage = "url(Imagens/bola.jpg)";
        obj.style.backgroundRepeat = "no-repeat"
        obj.style.backgroundPosition = "center";
        player.innerHTML = "Jogador X";

        draw++;

        setTimeout(function() {
            verifica(obj, "bola");
        }, 50);
    }

}

function vencedor(igual, image) {
    if (igual == 3) {
        if (image == "bola")
            message.innerHTML = "O jogador O ganhou!!";
        else
            message.innerHTML = "O jogador X ganhou!!";

        setTimeout("create(); message.innerHTML = '';", 5000);
    } else if (draw == num * num) {
        message.innerHTML = "Empate!!!";
        setTimeout("create(); message.innerHTML = '';", 5000);
    }
    clearFrame();
}

function verifica(obj, image) {
    let line = -1;
    let colums = 0;
    let i = 0;
    let j = 0;

    while (i <= obj.id) {
        if (i % num == 0) {
            line++;
        }
        i++;
    }

    for (j = ((num * (line + 1)) - num); j < (num * (line + 1)); j++) {
        if (j < obj.id)
            colums++;
    }

    console.log("l: " + line + ", c: " + colums);

    //Verificação das Linhas
    let igualLine = 0;

    for (let l = num * line; l < num * (line + 1); l++) {
        console.log("l: " + l);
        if (document.getElementById(l).style.backgroundImage == obj.style.backgroundImage) {
            igualLine++;
            console.log("igualLine: " + igualLine);
        }
    }

    vencedor(igualLine, image);

    //Verificação das Colunas
    let igualColums = 0;

    for (let c = num - (num - colums); c <= (num * num - num + colums); c++) {
        console.log("c: " + c);
        if (document.getElementById(c).style.backgroundImage == obj.style.backgroundImage) {
            if (c == parseInt(parseInt(obj.id) - parseInt(num)) ||
                c == parseInt(parseInt(obj.id) + parseInt(num)) ||
                c == parseInt(parseInt(obj.id) - parseInt(num * 2)) ||
                c == parseInt(parseInt(obj.id) + parseInt(num * 2)) ||
                c == obj.id) {
                igualColums++;
                console.log("igualCol: " + igualColums);
            }
        }
    }

    vencedor(igualColums, image);

    //Verificação das diagonal Esquerda
    let igualDigEsq = 0;

    for (let d = 0; d < num * num; d++) {
        console.log("d: " + d);
        if (document.getElementById(d).style.backgroundImage == obj.style.backgroundImage) {
            if (d == parseInt(parseInt(obj.id) - parseInt(parseInt(num) + parseInt(1))) ||
                d == parseInt(parseInt(obj.id) + parseInt(parseInt(num) + parseInt(1))) ||
                d == parseInt(parseInt(obj.id) - (parseInt(num * 2) + parseInt(2))) ||
                d == parseInt(parseInt(obj.id) + (parseInt(num * 2) + parseInt(2))) ||
                d == obj.id) {
                igualDigEsq++;
                console.log("igualDigEsq: " + igualDigEsq);
            }
        }
    }

    vencedor(igualDigEsq, image);

    //Verificação das diagonal Direita
    let igualDigDir = 0;

    for (let e = (num - 1); e <= num * num - num; e++) {
        console.log("e: " + e);
        if (document.getElementById(e).style.backgroundImage == obj.style.backgroundImage) {
            if (e == parseInt(parseInt(obj.id) - parseInt(parseInt(num) - parseInt(1))) ||
                e == parseInt(parseInt(obj.id) + parseInt(parseInt(num) - parseInt(1))) ||
                e == parseInt(parseInt(obj.id) - (parseInt(num * 2) - parseInt(2))) ||
                e == parseInt(parseInt(obj.id) + (parseInt(num * 2) - parseInt(2))) ||
                e == obj.id) {
                igualDigDir++;
                console.log("igualDigDir: " + igualDigDir);
            }
        }
    }

    vencedor(igualDigDir, image);

}