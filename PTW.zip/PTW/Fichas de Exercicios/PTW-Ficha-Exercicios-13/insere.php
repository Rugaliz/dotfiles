<?php
header('content-type: application/json; charset=utf-8');

$json = json_decode($_POST['json']);

$user = $json->user;
$name = $json->nome;
$pass = $json->password;
$age = $json->age;
$select = $json->select;

try {


    // Set connection to BD
    $pdo = new PDO('mysql:host=estga-dev.clients.ua.pt; port:3306; dbname=ptw', 'ptw', 'ptw');
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $statement = $pdo->prepare("INSERT INTO ptw.Utilizadores (utilizador, nome, password, idade, categoria) VALUES (?,?,?,?,?)");
    $statement->execute([$user, $name, $pass, $age, $select]);

} catch (PDOException $e) {
    $json['erro'] = $e->getMessage();
    echo json_encode($json);
}
?>