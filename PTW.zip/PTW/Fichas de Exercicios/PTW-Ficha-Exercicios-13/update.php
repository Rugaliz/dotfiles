<?php

header('content-type: application/json; charset=utf-8');

$json = json_decode($_POST['json']);

$user = $json->user;
$name = $json->nome;
$pass = $json->password;
$age = $json->age;
$select = $json->select;
$old_user = $json->old;

try {
    $pdo = new PDO('mysql:host=estga-dev.clients.ua.pt; port:3306; dbname=ptw', 'ptw', 'ptw');

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $statement = $pdo->prepare("UPDATE ptw.Utilizadores SET utilizador = ?, nome = ?, password = ?, idade = ?, categoria = ? WHERE utilizador LIKE ?");
    $statement->execute([$user, $name, $pass, $age, $select, $old_user]);

}catch(PDOException $e) {
    $json['erro'] = $e->getMessage();
    echo json_encode([$user, $name, $pass, $age, $select]);
}

?>