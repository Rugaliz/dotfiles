let box = document.getElementById("box");
let nome = document.getElementById("nome");
let utilizador = document.getElementById("utilizador");
let pass = document.getElementById("pass");
let idade = document.getElementById("idade");
let categoria = document.getElementById("categoria");
let btn_gravar = document.getElementById("gravar");
let btn_delete = document.getElementById("delete");
let atual_user;

btn_delete.style.visibility = "hidden";

pesquisa();

function pesquisa() {
    // 1. Create a new XMLHttpRequest object
    let xhr = new XMLHttpRequest();
    xhr.responseType = 'json';
    box.innerHTML = "";

    // 4. This function will be called after the response is received from the server
    xhr.onload = function() {
        if (xhr.status == 200) {
            if (xhr.response.erro !== "none") {
                let span = document.createElement('p');
                span.innerHTML = xhr.response.erro;
                box.appendChild(span);
            }
            if (xhr.response.categoria.length == 0) {
                let span = document.createElement('p');
                span.innerHTML = "O array está vazio";
                box.appendChild(span);
            } else {
                xhr.response.categoria.forEach(element => {
                    let div = document.createElement('div');

                    for (let valor in element) {
                        let span = document.createElement('span');
                        span.innerHTML = element[valor] + " | ";
                        div.appendChild(span);
                    }

                    let hr = document.createElement('hr');
                    div.appendChild(hr);
                    let br = document.createElement('br');
                    div.appendChild(br);

                    div.addEventListener("click", function() {
                        let uti = div.innerHTML.split("|", 1)[0].trim();
                        div.style.backgroundColor = "lightgreen";

                        getInfo(uti);
                    })
                    box.appendChild(div);

                });
            }

        } else {
            window.alert("Error" + xhr.status + ": " + xhr.statusText);
        }
    };

    // 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
    xhr.open("GET", 'lista.php', true);
    // 3. Send the request to the server
    xhr.send();

}

function getInfo(uti) {
    $.ajax({
        type: 'POST',
        url: 'information.php',
        data: { json: JSON.stringify(uti.substring(6)) },
        dataType: 'json',
        success: function(response) {
            if (response.erro == "none") {
                response.categoria.forEach(element => {
                    btn_gravar.innerHTML = "Guardar";
                    utilizador.innerHTML = element.utilizador;
                    nome.innerHTML = element.nome;
                    pass.innerHTML = element.password;
                    idade.innerHTML = element.idade;
                    categoria.value = element.id;
                    atual_user = element.utilizador;
                    btn_delete.style.visibility = "visible"
                });
            } else {
                alert("Erro: " + response.erro);
            }

        }
    })
}

function insert() {
    let name = nome.innerHTML;
    let user = utilizador.innerHTML;
    let password = pass.innerHTML;
    let age = idade.innerHTML;
    let cat = categoria.value;

    if (name.length == 0) {
        alert("Insira um nome por favor!")
        return;
    } else if (user.length == 0) {
        alert("Insira um utilizador por favor!")
        return;
    } else if (password.length == 0) {
        alert("Insira uma password por favor!")
        return;
    } else if (age.length == 0) {
        alert("Insira uma idade por favor!")
        return;
    } else if (cat == "select") {
        alert("Insira uma categoria por favor!")
        return;
    }

    if (btn_gravar.innerHTML == "Gravar") {
        let data = {
            user: user,
            nome: name,
            password: password,
            age: age,
            select: cat
        }

        $.ajax({
            type: 'POST',
            url: 'insere.php',
            data: { json: JSON.stringify(data) },
            dataType: 'json',
            success: function(response) {}
        })
    } else {
        console.log("user: " + atual_user);
        let data2 = {
            user: user,
            nome: name,
            password: password,
            age: age,
            select: cat,
            old: atual_user
        }

        btn_gravar.innerHTML = "Gravar";
        $.ajax({
            type: 'POST',
            url: 'update.php',
            data: { json: JSON.stringify(data2) },
            dataType: 'json',
            success: function(response) {}
        })
    }

    reset();
    pesquisa();
}

function deleteUser() {
    $.ajax({
        type: 'POST',
        url: 'elimina.php',
        data: { json: JSON.stringify(atual_user) },
        dataType: 'json',
        success: function(response) {
            if (response.erro == "none") {
                btn_delete.style.visibility = "hidden";
                reset();
                pesquisa();
            } else
                alert("Erro: " + response.erro);
        }
    })
}

function reset() {
    nome.innerHTML = "";
    utilizador.innerHTML = "";
    pass.innerHTML = "";
    idade.innerHTML = "";
    categoria.value = "select";
    btn_gravar.innerHTML = "Gravar";
    atual_user = "";
}