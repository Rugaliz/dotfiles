$.ajax({
    type: 'POST',
    url: 'lista.php',
    dataType: 'json',
    success: function (response) {
        response.forEach(element => {
            let line = document.createElement("div");
            line.className = "line";
            line.innerHTML = element.utilizador + " | " + element.nome + " | " + element.idade + " | " + element.categoria;
            line.addEventListener("click", function () {
                for (var i = 0; i < document.getElementsByClassName("line").length; i++) {
                    document.getElementsByClassName("line")[i].style.backgroundColor = "white";
                }
                // Array.from(document.getElementsByClassName("line")).forEach(element => {
                //     element.style.backgroundColor = "white";
                // });
                line.style.backgroundColor = "lightgreen";
                editar(line);
                $.ajax({
                    type: 'POST',
                    url: 'info.php',
                    data: { json: JSON.stringify(line.innerHTML.split("|", 1)[0].trim()) },
                    dataType: 'json',
                    success: function (response) {
                        response.forEach(element => {
                            document.getElementById("nome").value = element.nome;
                            document.getElementById("user").value = element.utilizador;
                            document.getElementById("password").value = element.password;
                            document.getElementById("idade").value = element.idade;
                            document.getElementById("categoria").value = element.id;
                        });
                    }
                })
                $("#eliminar").css("display", "inline");
            })
            document.getElementsByClassName("info")[0].appendChild(line);
        });
    }
})
var user = "";
function editar(line) {
    user = line.innerHTML.split("|", 1)[0].trim();

}

function insert() {
    var nme = document.getElementById("nome").value;
    var usr = document.getElementById("user").value;
    var pass = document.getElementById("password").value;
    var agee = document.getElementById("idade").value;
    var selct = document.getElementById("categoria").value;
    var values = {
        user: usr,
        nome: nme,
        password: pass,
        age: agee,
        select: selct
    }
    $.ajax({
        type: 'POST',
        url: 'insere.php',
        data: { json: JSON.stringify(values) },
        dataType: 'json',
        success: function (response) { }
    })
}

function edit() {
    var nme = document.getElementById("nome").value;
    var usr = document.getElementById("user").value;
    var pass = document.getElementById("password").value;
    var agee = document.getElementById("idade").value;
    var selct = document.getElementById("categoria").value;
    var myUser = user;
    var values = {
        old_user: myUser,
        user: usr,
        nome: nme,
        password: pass,
        age: agee,
        select: selct
    }
    $.ajax({
        type: 'POST',
        url: 'editar.php',
        data: { json: JSON.stringify(values) },
        dataType: 'json',
        success: function (response) { }
    })
}
//Botão ELIMINAR
document.getElementsByTagName("button")[0].addEventListener("click", function(){
    $.ajax({
        type: 'POST',
        url: 'eliminar.php',
        data: { json: JSON.stringify(user) },
        dataType: 'json',
        success: function (response) {}
    })
});
//Botão GRAVAR
document.getElementsByTagName("button")[1].addEventListener("click", function () {
    if (user != "") {
        edit();
        //No fim define o user como não selecionado novamente
        user = "";
        Array.from(document.getElementsByClassName("line")).forEach(element => {
            element.style.backgroundColor = "white";
        });
        $("#eliminar").css("display", "none");
    } else {
        insert();
    }
});
//Botão RESET
document.getElementsByTagName("button")[2].addEventListener("click", function () {
    if (user != "") {
        user = "";
        Array.from(document.getElementsByClassName("line")).forEach(element => {
            element.style.backgroundColor = "white";
        });
        $("#eliminar").css("display", "none");
    }
})