<?php
header('Content-Type: application/json');
if (isset($_POST['json'])){
    $user = json_decode($_POST['json']);
}

try{
    include("conn.php");
    $statement = $pdo->prepare("DELETE FROM ptw.Utilizadores WHERE utilizador LIKE ?");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $statement->execute([$user]);
    echo json_encode($statement->fetchAll(PDO::FETCH_ASSOC));
} catch (PDOException $e){
    echo $e->getMessage();
}