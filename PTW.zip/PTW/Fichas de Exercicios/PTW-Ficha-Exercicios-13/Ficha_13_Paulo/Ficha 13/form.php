<form>
    <div class="form">

        <div style="padding: 10px;">
            <label>Utilizador:</label><input type="text" required id="user"> <label>Nome:</label><input type="text" required id="nome">
        </div>
        <div style="padding: 10px;">
            <label>Password:</label><input type="password" required id="password"> <label>Idade:</label><input type="number" min="0" class="number" required id="idade"> <label>Categoria:</label>
            <select required id="categoria">
                <option selected value="1">Técnico Informático</option>
                <option value="2">Estudante</option>
                <option value="3">Administrador de BD</option>
                <option value="4">Programador</option>
                <option value="5">Analista de Sistemas</option>
            </select>
        </div>

    </div>
    <div class="right-align">
        <button type="submit" id="eliminar" style="display: none">Eliminar</button><button type="submit">Gravar</button><button type="reset">Reset</button>
    </div>
</form>