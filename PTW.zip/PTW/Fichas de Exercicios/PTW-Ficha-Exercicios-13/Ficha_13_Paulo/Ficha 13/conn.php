<?php
$pdo = new PDO("mysql:host=estga-dev.clients.ua.pt; port:3306; dbname=ptw; charset=utf8", 'ptw', 'ptw');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);