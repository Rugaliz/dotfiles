<?php
header('Content-Type: application/json');
if (isset($_POST['json'])){
    $json = json_decode($_POST['json']);
}
$old_user = $json->old_user;
$nome = $json->nome;
$user = $json->user;
$password = $json->password;
$idade = $json->age;
$categoria = $json->select;

try{
    include("conn.php");
    $statement = $pdo->prepare("UPDATE ptw.Utilizadores SET utilizador = ?, nome = ?, password = ?, idade = ?, categoria = ? WHERE utilizador LIKE ?");
    $statement->execute([$user, $nome, $password, $idade, $categoria, $old_user]);
} catch (PDOException $e){
    echo $e->getMessage();
}