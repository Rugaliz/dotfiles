<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="utf-8">
        <title>Lista de Utilizadores</title>
        <link href="style.css" rel="stylesheet">
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    </head>

    <body>
        <?php include('form.php') ?>
        <h1>Lista de Utilizadores</h1>
        <div class="info"></div>
    </body>
    <script src="lista.js"></script>
</html>