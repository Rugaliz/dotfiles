<?php

try {
    include("conn.php");
    $statement = $pdo->prepare("SELECT utilizador, Utilizadores.nome, idade, CatUtilizadores.nome as categoria, CatUtilizadores.id FROM ptw.Utilizadores INNER JOIN ptw.CatUtilizadores ON ptw.Utilizadores.categoria = ptw.CatUtilizadores.id");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $statement->execute();
    echo json_encode($statement->fetchAll(PDO::FETCH_ASSOC));
} catch (PDOException $e) {
    echo $e->getMessage();
}
