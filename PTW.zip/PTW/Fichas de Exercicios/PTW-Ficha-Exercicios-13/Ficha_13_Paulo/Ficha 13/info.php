<?php
header('Content-Type: application/json');
if (isset($_POST['json'])){
    $user = json_decode($_POST['json']);
}

try{
    include("conn.php");
    $statement = $pdo->prepare("SELECT utilizador, Utilizadores.nome, password, idade, CatUtilizadores.nome as categoria, CatUtilizadores.id as id FROM ptw.Utilizadores INNER JOIN ptw.CatUtilizadores ON ptw.Utilizadores.categoria = ptw.CatUtilizadores.id WHERE ptw.Utilizadores.utilizador LIKE ?");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $statement->execute([$user]);
    echo json_encode($statement->fetchAll(PDO::FETCH_ASSOC));
} catch (PDOException $e){
    echo $e->getMessage();
}