<?php
header('Content-Type: application/json');
if (isset($_POST['json'])){
    $json = json_decode($_POST['json']);
}
$nome = $json->nome;
$user = $json->user;
$password = $json->password;
$idade = $json->age;
$categoria = $json->select;

try{
    include("conn.php");
    $statement = $pdo->prepare("INSERT INTO ptw.Utilizadores(utilizador, nome, password, idade, categoria) VALUES (?,?,?,?,?)");
    $statement->execute([$user, $nome, $password, $idade, $categoria]);
} catch (PDOException $e){
    echo $e->getMessage();
}