<?php
header('content-type: application/json; charset=utf-8');

$user = json_decode($_POST['json']);

try {
    // Set connection to BD
    $pdo = new PDO('mysql:host=estga-dev.clients.ua.pt; port:3306; dbname=ptw', 'ptw', 'ptw');
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $statement = $pdo->prepare("SELECT utilizador, Utilizadores.nome, password, idade, CatUtilizadores.nome as categoria, CatUtilizadores.id as id FROM ptw.Utilizadores INNER JOIN ptw.CatUtilizadores ON ptw.Utilizadores.categoria = ptw.CatUtilizadores.id WHERE ptw.Utilizadores.utilizador LIKE ?");
    $statement->execute([$user]);
    $json['categoria'] = $statement->fetchAll(PDO::FETCH_ASSOC);

    $json['erro'] = "none";

    // $statementAll = $pdo->prepare("SELECT utilizador, nome, 'password', idade FROM ptw.Utilizadores");
    // $statementAll->execute();
    // $json['utilizadores'] = $statementAll->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($json);
} catch (PDOException $e) {
    $json['erro'] = $e->getMessage();
    echo json_encode($json);

}
?>