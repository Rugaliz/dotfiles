<?php
header('content-type: application/json; charset=utf-8');

$user = json_decode($_POST['json']);

try {
    // Set connection to BD
    $pdo = new PDO('mysql:host=estga-dev.clients.ua.pt; port:3306; dbname=ptw', 'ptw', 'ptw');
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $statement = $pdo->prepare("DELETE FROM ptw.Utilizadores WHERE utilizador LIKE ?");
    $statement->execute([$user]);

    $json['erro'] = "none";
    echo json_encode($json);

} catch (PDOException $e) {
    $json['erro'] = $e->getMessage();
    echo json_encode($json);
}
?>