<?php
header('content-type: application/json; charset=utf-8');
try {
    // Set connection to BD
    $pdo = new PDO('mysql:host=estga-dev.clients.ua.pt; port:3306; dbname=ptw', 'ptw', 'ptw');
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $statement = $pdo->prepare("SELECT ptw.Utilizadores.utilizador, ptw.Utilizadores.nome as nomeUtilizador, ptw.Utilizadores.idade, ptw.CatUtilizadores.nome FROM ptw.CatUtilizadores INNER JOIN ptw.Utilizadores WHERE ptw.CatUtilizadores.id LIKE ptw.Utilizadores.categoria");
    $statement->execute();
    $json['categoria'] = $statement->fetchAll(PDO::FETCH_ASSOC);

    $json['erro'] = "none";

    // $statementAll = $pdo->prepare("SELECT utilizador, nome, 'password', idade FROM ptw.Utilizadores");
    // $statementAll->execute();
    // $json['utilizadores'] = $statementAll->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($json);
} catch (PDOException $e) {
    $json['erro'] = $e->getMessage();
    echo json_encode($json);

}
?>