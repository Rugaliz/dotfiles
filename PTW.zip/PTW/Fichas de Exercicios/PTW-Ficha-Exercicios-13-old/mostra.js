let box = document.getElementById("box");

// function pesquisa() {
// 1. Create a new XMLHttpRequest object
let xhr = new XMLHttpRequest();
xhr.responseType = 'json';
box.innerHTML = "";

// 4. This function will be called after the response is received from the server
xhr.onload = function() {
    if (xhr.status == 200) {
        if (xhr.response.erro !== "none") {
            let span = document.createElement('p');
            span.innerHTML = xhr.response.erro;
            box.appendChild(span);
        }
        if (xhr.response.categoria.length == 0) {
            let span = document.createElement('p');
            span.innerHTML = "O array está vazio";
            box.appendChild(span);
        } else {
            xhr.response.categoria.forEach(element => {
                let div = document.createElement('div');

                for (let valor in element) {
                    let span = document.createElement('span');
                    span.innerHTML = element[valor] + " | ";
                    div.appendChild(span);
                }

                let hr = document.createElement('hr');
                div.appendChild(hr);
                let br = document.createElement('br');
                div.appendChild(br);
                box.appendChild(div);

            });
        }

    } else {
        window.alert("Error" + xhr.status + ": " + xhr.statusText);
    }
};

// 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
xhr.open("GET", 'lista.php', true);
// 3. Send the request to the server
xhr.send();

// }