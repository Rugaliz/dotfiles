// add to work
let taskDate = document.getElementById("taskDate");
let taskName = document.getElementById("taskName");
let add = document.getElementById("add");
let list = document.getElementById("list");
let i = 0;
let select;

add.addEventListener("click", function() { addTask() });

//Instanciação do date picker
instance = new dtsel.DTS('input[id="taskDate"]', {
    direction: 'BOTTOM',
    dateFormat: "dd-mm-yyyy",
});

function addTask() {
    if (add.innerHTML == "+") {
        if (taskName.innerHTML != "" && taskDate.value != "") {
            let item = document.createElement("div");
            item.id = i;
            item.addEventListener("click", function() { modifyTask(this) });
            list.appendChild(item);
            i++;

            let itemName = document.createElement("span");
            itemName.className = "listText";
            itemName.id = "name";
            itemName.innerHTML = taskName.innerHTML;
            item.appendChild(itemName);

            let itemDate = document.createElement("span");
            itemDate.className = "listText";
            itemDate.id = "date";
            itemDate.innerHTML = (" (" + taskDate.value + ")");
            item.appendChild(itemDate);

            let itemRemove = document.createElement("div");
            itemRemove.className = "remove";
            itemRemove.innerHTML = "-";
            itemRemove.addEventListener("click", function() { remove(item) });
            item.appendChild(itemRemove);
        }

    } else if (add.innerHTML == "V") {
        add.innerHTML = "+";
        let modified = document.getElementById(select);
        modified.innerHTML = "";

        let itemName = document.createElement("span");
        itemName.className = "listText";
        itemName.id = "name";
        itemName.innerHTML = taskName.innerHTML;
        modified.appendChild(itemName);

        let itemDate = document.createElement("span");
        itemDate.className = "listText";
        itemDate.id = "date";
        itemDate.innerHTML = (" (" + taskDate.value + ")");
        modified.appendChild(itemDate);

        let remove = document.createElement("div");
        remove.className = "remove";
        remove.innerHTML = "-";
        remove.addEventListener("click", function() { remove(modified) })
        modified.appendChild(remove);

        modified.style.backgroundColor = "white";
        modified.style.color = "green";
    }
}

function modifyTask(obj) {
    obj.style.backgroundColor = "black";
    obj.firstChild.style.color = "white";
    obj.firstChild.nextSibling.style.color = "white";
    add.innerHTML = "V";
    select = obj.id;
    taskName.innerHTML = obj.firstChild.innerHTML;
    taskDate.value = obj.firstChild.nextSibling.innerHTML;
}

function remove(obj) {
    setTimeout(function() {
        taskName.innerHTML = ' ';
        taskDate.value = ' ';
        add.innerHTML = '+';
        list.removeChild(obj);
    }, 2)
}