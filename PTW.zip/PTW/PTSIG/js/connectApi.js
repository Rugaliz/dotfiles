function connectAPI(points) {
    var travelStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.3,
                src: "icons/travel.png",
            }),
        }),
    ];
    let request = new XMLHttpRequest();

    request.open(
        "POST",
        "https://api.openrouteservice.org/v2/directions/foot-walking/geojson"
    );

    request.setRequestHeader(
        "Accept",
        "application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8"
    );
    request.setRequestHeader("Content-Type", "application/json");
    request.setRequestHeader(
        "Authorization",
        "5b3ce3597851110001cf6248fc3235604fa4433dabad3bec7973c459"
    );

    request.onreadystatechange = function() {
        if (this.readyState === 4) {
            // Definição da variável onde são armezandos os valores devolvidos pela api
            let dataAPI = JSON.parse(this.response);

            //Adição do boneco no ponto de partida
            let ManPoint;
            if (startPointSelected) {
                ManPoint = new ol.Feature({
                    geometry: new ol.geom.Point(startPoint),
                });
            } else {
                ManPoint = new ol.Feature({
                    geometry: new ol.geom.Point(ol.proj.fromLonLat(dataAPI.features[0].geometry.coordinates[0])),
                });
            }
            //Adição da feature à source
            src.addFeature(ManPoint);
            ManPoint.setStyle(travelStyle);

            setTimeout(function() {
                src.clear();

                //Caso tenha sido selecionado o ponto de partida adiciona-o aos pontos a apresentar juntamente com a rota
                if (startPointSelected) {
                    let featureStartPoint = new ol.Feature({
                        geometry: new ol.geom.Point(startPoint),
                    });
                    //Adição da feature à source
                    src.addFeature(featureStartPoint);
                    featureStartPoint.setStyle(flagStyle);
                } else {
                    //Caso não exista um ponto de partida selecionado, é adicionado ao primeiro ponto selecionado o estilo de ponto inicial
                    let featureStartPoint = new ol.Feature({
                        geometry: new ol.geom.Point(
                            ol.proj.fromLonLat(dataAPI.features[0].geometry.coordinates[0])
                        ),
                    });
                    //Adição da feature à source
                    src.addFeature(featureStartPoint);
                    featureStartPoint.setStyle(flagStyle);
                }

                //Definição de uma feature de multi pontos com os pontos selecionados -> Apresentada no mapa
                var featureListaDePontosASerApresentados = new ol.Feature({
                    geometry: new ol.geom.MultiPoint(listaDePontosASerApresentados),
                });
                src.addFeature(featureListaDePontosASerApresentados);

            }, 10);

            // console.log('Status:', this.status);
            // console.log('Headers:', this.getAllResponseHeaders());
            // console.log('Body:', this.response);

            //A uma variável são atribuídos os valores das coordenadas enviadas pela API
            //Antes disso é adicionado o ponto inicial ao array
            //Estes valores, já no lado do cliente, serão enviados para uma feature que criará uma linha atravessante de todas essas coordenadadas
            let pointsCoordinates = [];
            if (startPointSelected) {
                pointsCoordinates.push(startPoint);
            }
            dataAPI.features[0].geometry.coordinates.forEach((element) => {
                pointsCoordinates.push(ol.proj.fromLonLat(element));
            });
            //Criação da feature
            var featureLine = new ol.Feature({
                geometry: new ol.geom.LineString(pointsCoordinates),
            });
            //Definiçaõ de uma nova source e atribuição da feature anteriormente falada (linha)
            vectorLine = new ol.source.Vector({});
            vectorLine.addFeature(featureLine);
            //Definição de uma nova layer, a qualquer terá o estilo (lineStyle) definido no início do documento e a source como a source (vectorLine) anteriormente criada
            var vectorLineLayer = new ol.layer.Vector({
                displayInLayerSwitcher: false,
                source: vectorLine,
                style: lineStyle,
            });

            path = vectorLine.getFeatures()[0];

            //Atribuição da layer à variável global, que será posteriormente utilizado para remover a linha após conclusão da rota
            lineLayer = vectorLineLayer;
            map.addLayer(vectorLineLayer);

            startAnimation();
        }
    };
    // let corr = "[[8.681495,49.41461],[8.686507,49.41943],[8.687872,49.420318]]";
    //Caso o utilizador tenha escolhido um ponto inicial
    //Os dados enviados para a API começam e acabam com o ponto selecionado
    if (startPointSelected) {
        //Substituição do último valor do array pelo valor da posição inicial ao invés do valor da segunda posição (devolvido pelo TSP da BD)
        console.log("points: " + points, ", pos0" + pos[0] + ", pos1: " + pos[1]);
        points[points.length - 1] = "[" + pos[0] + "," + pos[1] + "]";
        //Definição do corpo do pedido à API composto pelo ponto de partida selecionado + o array de pontos ordenados pela BD
        var body =
            '{"coordinates":' +
            "[" +
            "[" +
            pos[0] +
            "," +
            pos[1] +
            "]," +
            points +
            "]" +
            "}";
    } else {
        //Caso contrário, os dados enviados começam e acabam no ponto selecionado para inicio por parte do TSP da BD
        var body = '{"coordinates":' + "[" + points + "]" + "}";
    }
    //console.log(body);

    request.send(body);
}