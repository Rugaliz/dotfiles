(function ($) {

	"use strict";

	var fullHeight = function () {

		$('.js-fullheight').css('height', $(window).height());
		$(window).resize(function () {
			$('.js-fullheight').css('height', $(window).height());
		});

	};
	fullHeight();

	$('#sidebarCollapse').on('click', function () {
		$('#sidebar').toggleClass('active');
		if ($(window).width() >= 992) {
			if ($('#sidebar').hasClass('active')) {
				$('#map').animate({ "margin-left": '-=300' });
			} else {
				$('#map').animate({ "margin-left": '+=300' });
			}
		} else {
			$('#map').css('margin-left', '0px');
		}
	});

	$(window).ready(function(){
		if ($(window).width() >= 992) {
			$('.custom-menu').css('display', 'none');
			$('#map').css('margin-left', '300px');
		} else {
			$('.custom-menu').css('display', 'block');
			$('#map').css('margin-left', '0px');
		}
	})

	$(window).resize(function () {
		if ($(window).width() >= 992) {
			$('.custom-menu').css('display', 'none');
			$('#map').css('margin-left', '300px');
		} else {
			$('.custom-menu').css('display', 'block');
			$('#map').css('margin-left', '0px');
		}
	});

})(jQuery);
