function setRota() {
    document
        .getElementById("botaoFazerRota")
        .addEventListener("click", function() {
            //Texto == "Apagar Rota" => Desaparecem os campos associados à rota e é definido o ponto inicial como não selecionado
            if (this.innerHTML == "Apagar Rota") {
                if (startPointSelected) {
                    startPointSelected = false;
                    startPoint = "";
                    $("#botaoPontoInicial").html("Escolher ponto de partida");
                }
                //Define a lista de valores selecionados como 0, apagando todos os anteriormente selecionados
                listaDePontosSelecionados.length = 0;
                listaDePontosASerApresentados.length = 0;
                listaDeNodeDePontosSelecionados.length = 0;
                src.clear();
                $("#pontosTitle").css("display", "none");
                $("#caixaPontos").css("display", "none");
                $("#botaoFazerRota").css("display", "none");
                $("#sort-all").prop("checked", true);
                $("#sort-null").prop("checked", true);
                $("#search_text").prop("disabled", false);
                $("#botaoPontoInicial").css("display", "block");
                $("#select").css("display", "block");
                $("#select2").css("display", "block");
                $("#multiple-datasets").css("display", "block");
                document.getElementById("helper").style.display = "block";
                this.innerHTML = "Iniciar Rota";
                //Aqui remove a rota do mapa e adicionar o layer "teste" que possui todos os pontos
                map.removeLayer(lineLayer);

                src = new ol.source.Vector({
                    url: "init.php",
                    format: new ol.format.GeoJSON(),
                });
                teste = new ol.layer.Vector({
                    displayInLayerSwitcher: false,
                    name: "pontos",
                    title: "Pontos Turísticos de Aveiro",
                    source: src,
                    style: funcão_style,
                });
                teste.setZIndex(99);
                map.addLayer(teste);
            } else {
                //Verifica a existência de OU menos de dois pontos para a rota com o ponto inicial selecionado OU menos de três pontos para a rota sem o ponto inicial selecionado
                //Caso alguma destas condições se verifique, apresenta uma mensagem de informação ao utilizador
                if (
                    (listaDePontosSelecionados.length < 2)
                ) {
                    // window.alert(
                    //     "Selecione pelo menos dois pontos de interesse para efetuar o cálculo da rota"
                    // );

                    // Control
                    var notification = new ol.control.Notification({});
                    map.addControl(notification);

                    notification.show('Selecione pelo menos dois pontos de interesse para efetuar o cálculo da rota');
                } else {
                    this.innerHTML = "Apagar Rota";
                    popup.hide();
                    bancos_selecao = 0;
                    $("#search_text").prop("disabled", true);
                    $("#botaoPontoInicial").css("display", "none");
                    $("#select").css("display", "none");
                    $("#select2").css("display", "none");
                    $("#multiple-datasets").css("display", "none");
                    document.getElementById("helper").style.display = "none";
                    //Os ícones do lixo desaparecem, proibindo o utilizador de eliminar pontos após a rota ter sido iniciada (Pontos são apagados na sua totalidade na condição if acima -> Após a rota começar)
                    document
                        .getElementById("caixaPontos")
                        .querySelectorAll("li")
                        .forEach((element) => {
                            element.removeChild(element.querySelector("i"));
                        });

                    console.log("pontos selecionadios: " + listaDeNodeDePontosSelecionados);

                    var xhrPedidoRouting = new XMLHttpRequest();

                    xhrPedidoRouting.onload = function() {
                        let data = JSON.parse(xhrPedidoRouting.response);
                        //console.log(data);
                        let points = new Array();

                        data.forEach((element) => {
                            let obj_point = new Array();
                            obj_point.push(element.x);
                            obj_point.push(element.y);

                            points.push("[" + obj_point + "]");
                        });

                        points.push(points[0]);
                        connectAPI(points);
                    };
                    xhrPedidoRouting.onerror = function() {
                        console.alert("");
                    };

                    xhrPedidoRouting.open("POST", "./php/gerateRoute.php", true);
                    var listaDeNodes = new FormData();
                    listaDeNodes.append("listaDeNodes", listaDeNodeDePontosSelecionados);
                    xhrPedidoRouting.send(listaDeNodes);
                    map.removeLayer(bancosShow);
                }
            }
        });
}