function funcão_style(feature, resolution) {
    //Definição dos estilos dos pontos
    var defaultStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                //     size: [52, 52],
                //     offset: [52, 0],
                //     opacity: 1,
                scale: 0.05,
                src: "icons/icone.png",
            }),
        }),
    ];



    var fontaintStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.15,
                src: "icons/fontaint1.png",
            }),
        }),
    ];

    var artCenterStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.15,
                src: "icons/art_center.png",
            }),
        }),
    ];

    var theaterStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.15,
                src: "icons/theater1.png",
            }),
        }),
    ];

    var librarieStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.15,
                src: "icons/librarie.png",
            }),
        }),
    ];

    var ferryStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.18,
                src: "icons/ferry1.png",
            }),
        }),
    ];

    var diveStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.2,
                src: "icons/dive1.png",
            }),
        }),
    ];

    var coffeStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.15,
                src: "icons/coffe1.png",
            }),
        }),
    ];

    var barStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.15,
                src: "icons/bar1.png",
            }),
        }),
    ];

    var clubStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.15,
                src: "icons/club.png",
            }),
        }),
    ];

    var cinemaStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.15,
                src: "icons/cinema.png",
            }),
        }),
    ];

    var travelStyle = [
        new ol.style.Style({
            image: new ol.style.Icon({
                anchor: [0.5, 0.5],
                scale: 0.3,
                src: "icons/travel.png",
            }),
        }),
    ];





    //console.log("fetaure: " + feature.get("amenity"));

    if (feature.get("amenity") === "fontes") {
        return fontaintStyle;
    } else if (feature.get("amenity") === "artes") {
        return artCenterStyle;
    } else if (feature.get("amenity") === "teatros") {
        return theaterStyle;
    } else if (feature.get("amenity") === "bibliotecas") {
        return librarieStyle;
    } else if (feature.get("amenity") === "bancos") {
        return bencheStyle;
    } else if (feature.get("amenity") === "ferry") {
        return ferryStyle;
    } else if (feature.get("amenity") === "mergulhos") {
        return diveStyle;
    } else if (feature.get("amenity") === "cafes") {
        return coffeStyle;
    } else if (feature.get("amenity") === "bar") {
        return barStyle;
    } else if (feature.get("amenity") === "discotecas") {
        return clubStyle;
    } else if (feature.get("amenity") === "cinemas") {
        return cinemaStyle;
    } else if (feature.get("amenity") === "teste") {
        return travelStyle;
    } else {
        return defaultStyle;
    }
}