function type() {
  var arts = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=artes",
});
var bench = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=bancos",
});
var bar = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=bar",
});
var library = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=bibliotecas",
});
var coffee = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=cafes",
});
var cinema = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=cinemas",
});
var disco = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=discotecas",
});
var ferry = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=ferry",
});
var fountain = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=fontes",
});
var dive = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=mergulhos",
});
var theatre = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: "./hintQuery.php?name=teatros",
});
$("#multiple-datasets .typeahead").typeahead({
    highlight: true,
}, {
    name: "arts-points",
    display: "name",
    source: arts.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Artes</h3>',
    },
}, {
    name: "bench-points",
    display: "name",
    source: bench.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Bancos</h3>',
    },
}, {
    name: "bar-points",
    display: "name",
    source: bar.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Bares</h3>',
    },
}, {
    name: "library-points",
    display: "name",
    source: library.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Bibliotecas</h3>',
    },
}, {
    name: "coffee-points",
    display: "name",
    source: coffee.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Cafés</h3>',
    },
}, {
    name: "cinema-points",
    display: "name",
    source: cinema.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Cinemas</h3>',
    },
}, {
    name: "disco-points",
    display: "name",
    source: disco.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Discotecas</h3>',
    },
}, {
    name: "ferry-points",
    display: "name",
    source: ferry.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Ferry</h3>',
    },
}, {
    name: "fountains-points",
    display: "name",
    source: fountain.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Fontes</h3>',
    },
}, {
    name: "dive-points",
    display: "name",
    source: dive.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Mergulho</h3>',
    },
}, {
    name: "theatre-points",
    display: "name",
    source: theatre.ttAdapter(),
    templates: {
        header: '<h3 class="type-name">Teatros</h3>',
    },
});
}
