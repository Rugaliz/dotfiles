function helper() {
  document.getElementById("helper").addEventListener("click", function () {
    introJs()
      .setOptions({
        nextLabel: "Seguinte",
        prevLabel: "Anterior",
        doneLabel: "Terminar",
        showBullets: true,
        steps: [
          {
            element: document.getElementById("title"),
            intro:
              "A aplicação Web SIG 'FindARoute' apresenta-lhe os pontos de turismo no concelho de Aveiro e zonas adjacentes ao mesmo.<br>Aproxime o mapa, descubra os pontos e selecione-os, para os adicionar à sua rota!",
          },
          {
            element: document.getElementById("multiple-datasets"),
            intro:
              "Esta opção permite-lhe, através da inserção de texto, a filtragem de pontos numa lista através do seu nome.<br>Experimente selecionar um item da lista e surpreenda-se com o resultado!",
          },
          {
            element: document.getElementById("categorias"),
            intro:
              "Aqui, pode filtrar todos os pontos de acordo com a categoria associada aos mesmos. <br>Experimente por si mesmo!",
          },
          {
            element: document.getElementById("tempoBancos"),
            intro:
              "Aqui, pode selecionar o tempo de pesquisa à volta do ponto selecionado. <br>Experimente por si mesmo e encontre todos os bancos!",
          },
          {
            element: document.getElementById("botaoPontoInicial"),
            intro:
              "Se deseja começar a sua rota num ponto escolhido por si, selecione esta opção e de seguida selecione, no mapa, a localização à sua escolha.",
          },
          {
            element: document.getElementById("switch"),
            intro:
              "Aqui, pode alternar entre o mapa de calor relativo à incidência de pontos no mapa. <br>Experimente por si mesmo este atraente botão!",
          },
          {
            element: document.getElementById("layerSwitcher"),
            intro:
              "Para alterar o mapa de fundo que a aplicação lhe demonstra, selecione aqui um mapa à sua escolha.",
          },
        ],
      })
      .start();
    introJs().onbeforechange(function (targetElement) {
      if (targetElement.style.display == "gone")
        // if targetElement does not exist
        introJS().nextStep(); // go to the next step
    });
  });
}
