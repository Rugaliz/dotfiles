function clickListaPontos() {
  var select = new ol.interaction.Select();
//Click na lista de pontos
$("#multiple-datasets .typeahead").on(
    "typeahead:selected",
    function(e, datum) {
        var nome = datum.name;
        teste.getSource().forEachFeature(function(feature) {
            let att = feature.get("name");
            if (att == nome) {
                var features = select.getFeatures();
                features.push(feature);
            }
        });

        select.getFeatures().forEach(function(feature) {
            var ext = feature.getGeometry().getExtent();
            var center = ol.extent.getCenter(ext);
            //Definição da mesma view extent inicial de modo a bloquear o mapa
            map.setView(
                new ol.View({
                    projection: "EPSG:3857", //or any projection you are using
                    center: [center[0], center[1]], //zoom to the center of your feature
                    zoom: 20, //here you define the levelof zoom
                    extent: [-981680.9024284289,
                        4914091.505177029, -923130.138761984,
                        4992708.507384772,
                    ], //here you define the maximum e minimum lat and long from where you can move the map
                })
            );
        });

        $("#multiple-datasets .typeahead").typeahead("val", "");
    }
);
}
