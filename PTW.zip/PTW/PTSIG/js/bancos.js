function bancos(coordinateBanco) {
    let request = new XMLHttpRequest();
    
    //Pedido feito a API openroute de forma a recebr informação para criar isochrone
    request.open(
        "POST",
        "https://api.openrouteservice.org/v2/isochrones/foot-walking"
    );

    request.setRequestHeader(
        "Accept",
        "application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8"
    );
    request.setRequestHeader("Content-Type", "application/json");
    request.setRequestHeader(
        "Authorization",
        "5b3ce3597851110001cf6248fc3235604fa4433dabad3bec7973c459"
    );

    map.removeLayer(bancosShow);
    map.removeLayer(bancosVector); // remove previous drawn layer
    request.onreadystatechange = function () {
        if (this.readyState === 4) {

            //Clear ao array de Features dos bancos de forma a resetar
            bancos_coordinates = [];

            var feat = JSON.parse(this.response);
            //lançamento do array de coordenadas do array de bancos
            var dataBancos = feat.features[0].geometry.coordinates;

            let bancosArray = [];

            //Envio das coordenadas individuais de cada banco para um array sendo que é feita a transformaão das mesmas para LonLat
            dataBancos[0].forEach((element) => {
                bancosArray.push(ol.proj.fromLonLat(element));
            });


            //com o array conseguido acima é criada uma Feature Polygon usando as coordenadas dos pontos
            var featureBanco = new ol.Feature({
                geometry: new ol.geom.Polygon([bancosArray]),

            });

            //lançamento das coordenadas de todos os bancos individualmente par aum array para comparação na API
            obj_bancos.features.forEach(element => {
                bancos_coordinates.push(ol.proj.fromLonLat(element.geometry.coordinates));
            });

            //Criação de um array de pontos e poligono do turf 
            var pointsbancos = turf.points(bancos_coordinates);
            var polygonbancos = turf.polygon([bancosArray]);

            //Função do turf que permite através de um array de pontos e um poligono verificar os pontos que se encontram dentro do mesmo
            var ptsWithin = turf.pointsWithinPolygon(pointsbancos, polygonbancos);


            bancosSource = new ol.source.Vector({});

            //Verificação de existência prévia de uma Layer para eliminar de forma a manter atualizado
            if (bancosVector !== 'undefined') { map.removeLayer(bancosVector) }
            bancosVector = new ol.layer.Vector({
                displayInLayerSwitcher: false,
                source: bancosSource,
                style: bencheStyle,
            });

            map.addLayer(bancosVector);

            ptsWithin.features.forEach(element => {

                var bancoPonto = new ol.Feature({
                    geometry: new ol.geom.Point(element.geometry.coordinates),
                })
                bancosSource.addFeature(bancoPonto);

                //Animação que faz aparecer os bancos de cima para baixo
                bancosVector.animateFeature(bancoPonto, [new ol.featureAnimation['Drop']({
                    speed: 1,
                    duration: Number(1000 - 1 * 300),
                    side: false
                }),
                new ol.featureAnimation['Bounce']({
                    speed: 1,
                    duration: Number(1000 - 1 * 300),
                    horizontal: /Slide/.test('Drop')
                })
                ]);
            });

            vectorBanco = new ol.source.Vector({});
            vectorBanco.addFeature(featureBanco);

            if (bancosShow !== 'undefined') { map.removeLayer(bancosShow) }
            bancosShow = new ol.layer.Vector({
                displayInLayerSwitcher: false,
                source: vectorBanco,
                style: tiloBanco,
            });

            map.addLayer(bancosShow);
        }
    };
    let distTemporal = bancos_selecao;
    
    //corpo do pedido feito a API
    const body =
        '{"locations":[[' +
        coordinateBanco[0] +
        "," +
        coordinateBanco[1] +
        "],[" +
        coordinateBanco[0] +
        "," +
        coordinateBanco[1] +
        ']],"range":[' + distTemporal + '],"range_type":"time"}';
    
    if (distTemporal > 0) {
        request.send(body);
    }
}

//Receção da opção referente à distância a que se pretende mostrar os bancos
var bancos_selecao = 0;
$(".dropdown-el.bancos").click(function (s) {
    s.preventDefault();
    s.stopPropagation();
    $(this).toggleClass("expanded");
    $("#" + $(s.target).attr("for")).prop("checked", true);
    if (bancos_selecao != $("#" + $(s.target).attr("for")).val()) {
        bancos_selecao = $("#" + $(s.target).attr("for")).val();
    }
});
$(document).click(function () {
    $(".dropdown-el.bancos").removeClass("expanded");
});