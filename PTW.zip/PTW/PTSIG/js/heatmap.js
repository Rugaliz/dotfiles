function heatmap(){

data = new ol.source.Vector();
    for (const key in obj_pontos.features) {
        // console.log(obj_pontos.features[key]);
        var pointFeature = new ol.Feature({
            geometry: new ol.geom.Point(
                ol.proj.fromLonLat(obj_pontos.features[key].geometry.coordinates)
            ),
            weight: 20, // e.g. temperature
        });
        if(obj_pontos.features[key].properties.amenity != "bancos") data.addFeature(pointFeature);
    }

    

    var vector = new ol.layer.Heatmap({
        displayInLayerSwitcher: false,
        name: "heatmap",
        source: data,
        blur: 15,
        radius: 15,
        weight: function(feature) {
            return 0.3;
        },
    });
    vector.setZIndex(0);
    map.addLayer(vector);
    

    var heatmapSwitch = document.getElementById("switchHeatmap");
    heatmapSwitch.checked = true;
    // var checkedHeatmapSwitch = heatmapSwitch.checked;

    var currZoom = map.getView().getZoom();
    map.on("moveend", function(e) {
        var newZoom = map.getView().getZoom();
        if (currZoom != newZoom) {
            // console.log("zoom end, new zoom: " + newZoom);
            currZoom = newZoom;
        }
        let zoomCalc = (currZoom - 12) / 3;
        vector.setOpacity(1 - zoomCalc);
        var layerBool = false;
        
        if (currZoom > 14) {
            map.getLayers().forEach((layer) => {
                if (layer && layer.get("name") === "heatmap") {
                    map.removeLayer(layer);
                }
            });
        } else {
            map.getLayers().forEach((layer) => {
                if (layer && layer.get("name") === "heatmap") {
                    layerBool = true;
                }
            });
            if (!layerBool && heatmapSwitch.checked) map.addLayer(vector);
        }
        if (heatmapSwitch.checked) {
            teste.setOpacity(zoomCalc);
        }

    });


    

    heatmapSwitch.addEventListener("click", function() {
        // heatmapSwitch.checked = !heatmapSwitch.checked;
        // console.log(checkedHeatmapSwitch);
        placeRemoveHeatmap(heatmapSwitch.checked);
    });

    function placeRemoveHeatmap(bool) {
        if (bool) {
            let zoomCalc = (map.getView().getZoom() - 12) / 3;
            map.addLayer(vector);
            teste.setOpacity(zoomCalc);
        } else {
            map.getLayers().forEach((layer) => {
                if (layer && layer.get("name") === "heatmap") {
                    map.removeLayer(layer);
                }
            });
            teste.setOpacity(1);
        }
    }
    teste.setZIndex(99);
};