function startAnimation() {
    if (path) {
        f = new ol.Feature({
            geometry: new ol.geom.Point([0, 0]),
        });

        var gifUrl = "icons/man2.gif";
        var gif = gifler(gifUrl);
        gif.frames(
            document.createElement('canvas'),
            function(ctx, frame) {
                if (!f.getStyle()) {
                    console.log("aaa: " + frame.width);
                    f.setStyle(
                        new ol.style.Style({
                            image: new ol.style.Icon({
                                img: ctx.canvas,
                                imgSize: [frame.width, frame.height],
                                scale: 0.3,
                                opacity: 1,
                            }),
                        })
                    );

                    anim = new ol.featureAnimation.Path({
                        path: path,
                        rotate: false,
                        easing: ol.easing["linear"],
                        speed: 1,
                        revers: false
                    });

                    lineLayer.animateFeature(f, anim);

                }
                ctx.clearRect(0, 0, frame.width, frame.height);
                ctx.drawImage(frame.buffer, frame.x, frame.y);
                map.render();

            },
            true
        );



        // volta para trás

        // vectorLine.addFeature(f);
        // anim.on('animationend', function(e) {
        //     if (e.feature) vectorLine.removeFeature(e.feature);
        // });

        // roda o mapa consoate a posição

        // anim.on('animating', (e) => {
        //     map.getView().setCenter(e.geom.getCoordinates())
        //     map.getView().setRotation(e.rotation || 0)
        // })


    }
}