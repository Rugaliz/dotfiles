function adicionarPontoListaDePontosSelecionados() {
    //Caso a rota esteja por iniciar permite a adição de pontos
    //Em caso contrário não faz nada
    if ($("#botaoFazerRota").html() == "Iniciar Rota") {
        $("#pontosTitle").css("display", "block");
        $("#botaoFazerRota").css("display", "block");
        let caixaPontos = document.getElementById("caixaPontos");
        caixaPontos.style.display = "block";
        caixaPontos.innerHTML = "";
        if (startPointSelected) {
            var itemInicial = document.createElement("li");
            itemInicial.className = "route_item";
            itemInicial.title = "Remover ponto da lista";
            itemInicial.innerHTML = "O MEU PONTO DE PARTIDA";
            caixaPontos.appendChild(itemInicial);
            itemInicial.innerHTML +=
                "<i class='fa fa-trash' style='float:right; margin-top:5px'></i>";
            itemInicial.addEventListener("click", function() {
                if ($("#botaoFazerRota").html() == "Iniciar Rota") {
                    startPointSelected = false;
                    startPoint = "";
                    caixaPontos.removeChild(this);
                    $("#botaoPontoInicial").html("Escolher ponto de partida");
                    a_selecionar = false;
                    src.removeFeature(featureStart);

                    //Remove os elementos referentes a uma rota após ficar sem elementos para apresentar
                    if (listaDePontosSelecionados.length == 0) {
                        $("#pontosTitle").css("display", "none");
                        $("#caixaPontos").css("display", "none");
                        $("#botaoFazerRota").css("display", "none");
                    }
                }
            });
        }
        for (const iterator of listaDePontosSelecionados) {
            let itemLista = document.createElement("li");
            itemLista.className = "route_item";
            itemLista.title = "Remover ponto da lista";
            //Caso o ponto inicial tenha sido definido adiciona-o como primeiro ponto da lista visível
            itemLista.addEventListener("click", function() {
                //A ação de remoção é apenas permitida aquando da rota por iniciar
                if ($("#botaoFazerRota").html() == "Iniciar Rota") {
                    //Remoção do ponto seleção dos arrays utilizados
                    let i = listaDePontosSelecionados.indexOf(iterator);
                    listaDePontosSelecionados.splice(i, 1);
                    listaDeNodeDePontosSelecionados.splice(i, 1);
                    listaDePontosASerApresentados.splice(i, 1);

                    //Remoção do ponto da lista
                    caixaPontos.removeChild(this);

                    if (listaDePontosSelecionados.length == 0) {
                        $("#pontosTitle").css("display", "none");
                        $("#caixaPontos").css("display", "none");
                        $("#botaoFazerRota").css("display", "none");
                    }
                }
            });
            if (iterator.values_.name != null) {
                itemLista.innerHTML = iterator.values_.name;
            } else {
                itemLista.innerHTML = "Ponto selecionado sem nome";
            }
            itemLista.innerHTML +=
                "<i class='fa fa-trash' style='float:right; margin-top:5px'></i>";
            caixaPontos.appendChild(itemLista);
        }
    }
}