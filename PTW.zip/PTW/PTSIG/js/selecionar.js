function selecionarMap() {
    map.on("click", function(e) {
        //Fecha um
        popup.hide();
        //Esta ação decorre apenas se não estiver a decorrer a seleção do ponto inicial
        if (!a_selecionar) {
            var feature = map.getFeaturesAtPixel(e.pixel)[0];
            if (feature && feature.values_.hasOwnProperty("amenity")) {
                console.log(feature);

                var coordinate = feature.getGeometry().getCoordinates();
                popup.setPosition(coordinate);
                // popup.setPosition(coordinate);
                //   console.log(coordinate);
                listaDePontosASerApresentados.push(coordinate);
                var covert = ol.proj.transform(coordinate, "EPSG:3857", "EPSG:4326");
                // console.log(covert);
                bancos(covert);
                //Comentado para não aparecer um ícone sobre os já presentes
                // var featureListaDePontosASerApresentados = new ol.Feature({
                //     geometry: new ol.geom.MultiPoint(listaDePontosASerApresentados),
                // });
                // src.addFeature(featureListaDePontosASerApresentados);
                listaDePontosSelecionados.push(feature);
                console.log(listaDeNodeDePontosSelecionados);
                listaDeNodeDePontosSelecionados.push(feature.values_.n_node);
                //É ordenada a adição do ponto selecionado à lista de pontos componentes da rota
                adicionarPontoListaDePontosSelecionados();
            }
        } else if (a_selecionar) {
            //Guarda numa variável global os valores das coordenadas do ponto selecionado no EPSG:3857 (mapa) e noutra no EPSG:4326 (Google - API + BD)
            //console.log(e.coordinate[0] + " : " + e.coordinate[1]);
            startPoint = e.coordinate;
            pos = ol.proj.transform(e.coordinate, "EPSG:3857", "EPSG:4326");
            console.log(pos[0] + " : " + pos[1]);
            //Ponto selecionado como ponto inicial do percurso
            //Atribuição do ponto a uma feature
            featureStart = new ol.Feature({
                geometry: new ol.geom.Point(ol.proj.fromLonLat([pos[0], pos[1]])),
            });
            //Adição da feature à source
            src.addFeature(featureStart);
            //Definição do estilo da featura
            featureStart.setStyle(flagStyle);
            //Alteração dos valores relativos à seleção do ponto de partida
            $("#botaoPontoInicial").html("Eliminar ponto de partida"); //Alteração do valor do botão
            $("#botaoPontoInicial").prop("disabled", false); //Botão passa a estar enabled
            setTimeout(function() {
                a_selecionar = false;
            }, 200); //Indica que já não está a ocorrer seleção do ponto
            //setTimeout(function () { a_selecionar = false; }, 200); //Indica que já não está a ocorrer seleção do ponto
            startPointSelected = true; //Indica que o ponto já foi selecionado
            //Adiciona o ponto à lista demonstrada
            adicionarPontoListaDePontosSelecionados();
        }
    });
}