var xhr = new XMLHttpRequest();
xhr.responseType = "json";
var obj_pontos;
var listaDePontosSelecionados = new Array();
var listaDeNodeDePontosSelecionados = new Array();
//Variáveis associadas ao ponto de partida escolhido pelo utilizador
//A variável startPoint armazena as coordenadas do ponto inicial selecionado pelo utilizador, no sistema de coordenadas utilizado pelo OpenLayers ('EPSG:3857')
var startPoint;
var startPointSelected = false;
//A variável pos armazena as coordenadas do ponto inicial selecionado pelo utilizador, no sistema de coordenadas utilizado pela API('EPSG:4326')
var pos;

// 4. This function will be called after the response is received from the server
xhr.onload = function () {
  if (xhr.status == 200) {
    console.log(xhr.response);
    obj_pontos = xhr.response;
  } else window.alert("Error" + xhr.status + ": " + xhr.statusText);

  heatmap();
};

// 2. Configure the XHR objetct - URL e.g: https://jsonplaceholder.typicode.com/photos
xhr.open("GET", "init.php", true);
// 3. Send the request to the server
xhr.send();

// Receber bancos da base de dados

var xhrbancos = new XMLHttpRequest();
xhrbancos.responseType = "json";
var obj_bancos;
var bancos_coordinates = [];
xhrbancos.onload = function () {
  if (xhrbancos.status == 200) {
    obj_bancos = xhrbancos.response;
    console.log(obj_bancos);
  } else window.alert("Error" + xhrbancos.status + ": " + xhrbancos.statusText);
};

xhrbancos.open("GET", "initbancos.php", true);

xhrbancos.send();

//POPUP
var popup;
//Criação do mapa definindo um target (id da div) indicar a layer base (mapa inicial) e declarando a vista do mesmo (definição do centro, limites de navegação e aproximação)

var map = new ol.Map({
  target: "map",
  controls: ol.control.defaults().extend([new ol.control.LayerPopup()]),
  layers: [
    new ol.layer.Tile({
      title: "Terreno",
      source: new ol.source.Stamen({
        layer: "terrain",
      }),
      baseLayer: true,
      visible: true,
    }),
    new ol.layer.Tile({
      title: "Satélite",
      source: new ol.source.XYZ({
        url:
          "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      }),
      baseLayer: true,
      visible: false,
    }),
    new ol.layer.Tile({
      title: "Desenho",
      source: new ol.source.Stamen({
        layer: "toner",
      }),
      baseLayer: true,
      visible: false,
    }),
  ],
  overlay: [popup],
  view: new ol.View({
    center: ol.proj.fromLonLat([-8.803223680136906, 40.63161442420522]),
    extent: [
      -981680.9024284289,
      4914091.505177029,
      -923130.138761984,
      4992708.507384772,
    ],
    //extent: ol.proj.fromLonLat([-3.639611570841403, 5.64975606369564, 45.63161442420522,30.63161442420522]),//-8.803223680136906, 40.63161442420522
    zoom: 9,
  }),
});

var ctrl = new ol.control.Scale({});
map.addControl(ctrl);
map.addControl(new ol.control.ScaleLine());

// Define a new legend
var legend = new ol.legend.Legend({
  title: "Legenda",
  margin: 5,
});
var legendCtrl = new ol.control.Legend({
  legend: legend,
  collapsed: false,
});
map.addControl(legendCtrl);
//legend.on('select', function(e){ console.log(e) });

// Add a new one

var form = {
  Fonte: "icons/fontaint1.png",
  "Centro de Arte": "icons/art_center.png",
  Teatro: "icons/theater1.png",
  Biblioteca: "icons/librarie.png",
  Bancos: "icons/benche1.png",
  Ferry: "icons/ferry1.png",
  Mergulho: "icons/dive1.png",
  Café: "icons/coffe1.png",
  Bar: "icons/bar1.png",
  Discoteca: "icons/club.png",
  Cinema: "icons/cinema.png",
  "Ponto Partida": "icons/flag.png",
};
var scaleInt = 0;
for (var i in form) {
  legend.addItem({
    title: i,
    typeGeom: "Point",
    style: new ol.style.Style({
      // image: new ol.style.RegularShape({
      //   points: form[i],
      //   radius: 15,
      //   stroke: new ol.style.Stroke({ color: [255, 128, 0, 1], width: 1.5 }),
      //   fill: new ol.style.Fill({ color: [255, 255, 0, 0.3] }),
      // }),
      image: new ol.style.Icon({
        // anchor: [0.25, 1],
        //     size: [52, 52],
        //     offset: [52, 0],
        //     opacity: 1,
        scale: 0.1,
        src: form[i],
      }),
    }),
  });
}

//Depois da criação do mapa define dimensoes do layer switcher
$("#layerSwitcher").css("width", "35px");
$("#layerSwitcher").css("height", "35px");

/*
var estiloBanco = [
    stroke: rgb(255, 0, 0);
    stroke-opacity: 1;
    stroke-width: 3;
    stroke-linecap: round;
    stroke-linejoin: round;
    fill: rgb(51, 136, 255);
    fill-opacity: 0.2;
    fill-rule: evenodd;
    d: path("M 173 150 L 182 198 L 186 202 L 215 180 L 231 178 L 235 161 L 233 157 L 200 139 L 189 137 L 173 148 Z");
];*/

var lineStyle = new ol.style.Style({
  fill: new ol.style.Fill({ color: "#009698", weight: 4 }),
  stroke: new ol.style.Stroke({ color: "#009698", width: 5 }), // "#0000FF" old color
});

//Definiçaõ de uma source, onde são armezandos todos os pontos na BD
var src = new ol.source.Vector({
  url: "init.php",
  format: new ol.format.GeoJSON(),
});
//Criação de uma layer, cujos pontos são dados pela source (src) e o estilo definido pela função função_style
var teste = new ol.layer.Vector({
  displayInLayerSwitcher: false,
  name: "pontos",
  title: "Pontos Turísticos de Aveiro",
  source: src,
  style: funcão_style,
  opacity: 0,
});

//Variável relativa à rota criada aquando da ação necessária para tal
var lineLayer;
//Adição da layer composta pelos pontos da bd ao mapa
teste.setZIndex(99);
map.addLayer(teste);

var flagStyle = [
  new ol.style.Style({
    image: new ol.style.Icon({
      anchor: [0.25, 1],
      //     size: [52, 52],
      //     offset: [52, 0],
      //     opacity: 1,
      scale: 0.1,
      src: "icons/flag.png",
    }),
  }),
];

var tiloBanco = [
  new ol.style.Style({
    stroke: new ol.style.Stroke({
      color: "#009698",
      width: 1,
    }),

    /*fill: new ol.style.Fill({
            color: "rgba(0, 0, 255, 0.1)",
        }),*/
  }),
];

var bencheStyle = [
  new ol.style.Style({
    image: new ol.style.Icon({
      anchor: [0.5, 0.5],
      scale: 0.15,
      src: "icons/benche1.png",
    }),
  }),
];

// import Select from 'ol/interaction/Select';
// import 'ol/ol.css';

//Perante o click do botão para iniciar a rota
setRota();
// Animation
var path;
var vectorLine;

// Add a feature on the map
var f, anim;

//seleção e registo de pontos no menu inicial
var selectClick = new ol.interaction.Select({
  condition: ol.events.condition.click,
});

map.addInteraction(selectClick);

var listaDePontosASerApresentados = [];
//Atribuição do pop-up ao ponto selecionado no mapa
selecionarMap();

startAnimation();
// var selectPointerMove = new ol.interaction.Select({
//     condition: ol.events.condition.pointerMove,
// });

// map.addInteraction(selectPointerMove);

// selectClick.on("select", function(e) {
//     if (!a_selecionar) {
//         if (e.selected.length == 1) {
//Guardam-se as variáveis num array para amostra e o nó mais próximo é guardado num array separado
// console.log(e);
// listaDePontosSelecionados.push(e.selected[0]);
// listaDeNodeDePontosSelecionados.push(e.selected[0].values_.n_node);
//É ordenada a adição do ponto selecionado à lista de pontos componentes da rota
// adicionarPontoListaDePontosSelecionados();
//         }
//     }
// });
//Adiciona os valores dos pontos selecionados à lista presente no menu

//criação da box com informaçao em mouseover

// Control Select
var select = new ol.interaction.Select({});
console.log("I clicked" + select);
map.addInteraction(select);

// Popup overlay
/*
var container = document.getElementById('popup');
var content = document.getElementById('popup-content');
var closer = document.getElementById('popup-closer');
 
var overlay = new Overlay({
    element: container,
    autoPan: true,
    autoPanAnimation: {
      duration: 250,
    },
  });
  */

popup = new ol.Overlay.Popup({
  popupClass: "default anim",
  closeBox: true,
  onclose: function () {
    // console.log("You close the box");
  },
  positioning: "auto",
  autoPan: true,
  autoPanAnimation: {
    duration: 100,
  },
});

map.addOverlay(popup);

select.getFeatures().on(["add"], function (e) {
  if (e.element.values_.hasOwnProperty("amenity")) {
    setTimeout(function () {
      let popupData = e.element;
      // console.log(popupData);
      let content = "";
      let nome;
      if (popupData.values_.name == null) {
        nome = "Ponto sem nome";
      } else nome = popupData.values_.name;
      content += "<br><label><strong>Nome:</strong> " + nome + "</label><br>";
      let tipo;
      tipo = popupData.values_.amenity;
      if (popupData.values_.amenity == null) {
        tipo = "NF";
      } else tipo = popupData.values_.amenity;
      tipo = tipo.charAt(0).toUpperCase() + tipo.slice(1);
      content += "<label><strong>Tipo:</strong> " + tipo + "</label>";
      popup.setPosition(popupData.getGeometry().getCoordinates());
      popup.show(popupData.getGeometry().getCoordinates(), content);
    }, 100);
  }
});
select.getFeatures().on(["remove"], function (e) {
  popup.hide();
});
//TOP BAR CONNECTION
//Text Input Search
var button = document.getElementById("search_btn");
var name_text = document.getElementById("search_text");
var filter = document.getElementById("categorias");
//O valor selecionado por defeito é de todas as categorias
var selecao = "all";

name_text.addEventListener("change", function () {
  pesquisa();
});
//Plugin typeahead twitter bootstrap
//Filtragem de pontos originada pelo select presente no menu lateral
function pesquisa() {
  src.clear();
  map.removeLayer(teste);
  if (selecao == "all") {
    src = new ol.source.Vector({
      url: "init.php",
      format: new ol.format.GeoJSON(),
    });
  } else {
    src = new ol.source.Vector({
      url: "searchFilter.php?filter=" + selecao,
      format: new ol.format.GeoJSON(),
    });

    document.getElementById("switchHeatmap").checked = false;
    map.getLayers().forEach((layer) => {
      if (layer && layer.get("name") === "heatmap") {
        map.removeLayer(layer);
      }
    });
    teste.setOpacity(1);
  }

  teste = new ol.layer.Vector({
    displayInLayerSwitcher: false,
    name: "pontos",
    title: "Pontos Turísticos de Aveiro",
    source: src,
    style: funcão_style,
  });

  // var newZoom = map.getView().getZoom();
  // if (newZoom > 13) {
  teste.setZIndex(99);
  map.addLayer(teste);
}

//Filter jQuery Categoria Pontos
$(".dropdown-el.categoria").click(function (p) {
  p.preventDefault();
  p.stopPropagation();
  $(this).toggleClass("expanded");
  $("#" + $(p.target).attr("for")).prop("checked", true);
  if (selecao != $("#" + $(p.target).attr("for")).val()) {
    selecao = $("#" + $(p.target).attr("for")).val();
    pesquisa();
  }
});
$(document).click(function () {
  $(".dropdown-el.categoria").removeClass("expanded");
});

//Filter Search
filter.addEventListener("change", function () {
  pesquisa();
});

//Variáveis relativas ao ponto de partida
var a_selecionar = false;
var featureStart;
var pos;
//Definição do clique no botão para escolha do ponto de partida
$("#botaoPontoInicial").click(function () {
  //Caso este já tenha sido escolhido, remove o ponto de partida do mapa, altera o valor do botão e define as variáveis globais associadas como false e vazio, indicando a não seleção de um ponto
  if ($("#botaoPontoInicial").html() == "Eliminar ponto de partida") {
    src.removeFeature(featureStart);
    $("#botaoPontoInicial").html("Escolher ponto de partida");
    startPoint = "";
    startPointSelected = false;
    document
      .getElementById("caixaPontos")
      .removeChild(document.getElementById("caixaPontos").firstChild);
  } else if ($("#botaoPontoInicial").html() == "Escolher ponto de partida") {
    // Se o ponto de partida estiver por selecionar (var a_selecionar = false), a_selecionar = true e o valor do botão muda, tornando-se disabled enquanto ocorre a seleção do ponto
    a_selecionar = true;
    $("#botaoPontoInicial").prop("disabled", true);
    $("#botaoPontoInicial").html(
      'Seleção de ponto inicial:<br> A DECORRER... <i class="fa fa-info-circle" aria-hidden="true" title="Seleciona um local do mapa para guardar o teu ponto de partida">'
    );
  } else {
  }
});

type();

clickListaPontos();

var bancosShow;
var bancosVector;

//Definição do intro
helper();
