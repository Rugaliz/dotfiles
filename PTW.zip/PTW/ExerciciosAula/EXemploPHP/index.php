<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="utf-8">
    <title>Exemplo PHP</title>
</head>

<body>
    <?php
        echo "teste PHP";
    ?>
</body>

</html>